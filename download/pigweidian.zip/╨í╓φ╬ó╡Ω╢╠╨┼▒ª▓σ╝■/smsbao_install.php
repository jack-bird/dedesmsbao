<?php
/**
 * 小猪微店系统短信宝插件安装
 * User: linf
 * Date: 2016/8/14
 * Time: 21:40
 */
require_once 'wap/global.php';
$sms_topdomain['info']='短信宝接口';
$sms_topdomain['value']='http://api.smsbao.com/sms';
$sms_topdomain['desc']='短信宝接口地址';
$sms_name['name']='sms_name';
$sms_name['type']='type=text&validate=required:true';
$sms_name['value']='';
$sms_name['info']='短信宝用户名';
$sms_name['desc']='短信宝注册地址：http://www.smsbao.com';
$sms_name['tab_id']='0';
$sms_name['tab_name']='平台短信平台';
$sms_name['gid']='15';
$sms_name['sort']='0';
$sms_name['status']='1';
$sms_key['info']='短信宝密码';
$sms_key['desc']='您在短信宝注册的密码';
$config1=D('Config')->where("name='sms_topdomain'")->data($sms_topdomain)->save();
$config2=D('Config')->where("name='sms_key'")->data($sms_key)->save();
$config3=D('Config')->data($sms_name)->add();
if($config1!='-1'&&$config2!='-1'){
  echo '短信宝插件安装成功，请及时删除smsbao_install.php文件';
}else{
  echo '请检查是否将smsbao_install.php放在根目录';
}
?>