<?php

// +----------------------------------------------------------------------
// | 短信宝短信接口自助免费申请：http://www.smsbao.com/
// +----------------------------------------------------------------------
/* 短信接口 */
class com_sms {
	
	private $result = array(

		'0'=>'说明：<br>提交成功',
		
		'30'=>'说明：<br>密码错误<br><br>解决方案：<br>请检查密码是否正确',
		
		'40'=>'说明：<br>账号不存在<br><br>解决方案：<br>请检查程序中账号是否正确设置',
		
		'41'=>'说明：<br>余额不足<br><br>解决方案：<br>请到<a href="http://www.smsbao.com" target="_blank">短信宝官网</a>进行充值',
		
		'42'=>'说明：<br>帐号过期<br><br>解决方案：<br>请联系短信宝客服 ',
		
		'43'=>'说明：<br>IP地址限制。<br><br>解决方案：<br>请联系短信宝客服或到短信宝会员中心进行设置',
		
		'50'=>'说明：<br>内容含有敏感词<br><br>解决方案：<br>请检查您您提交的内容，如有疑问，请联系短信宝客服',
		
		'51'=>'说明：<br>手机号码不正确<br><br>解决方案：<br>请检查手机号码是否有误',
		);	
	
	
	//获取短信余量
	function get_over() {
		$count = cls_config::get("count_id" , "sms");
		$pwd = cls_config::get("count_pwd" , "sms");
		$arr = fun_base::post("http://api.smsbao.com/query?u=" . $count . "&p=" . $pwd);
		$return_str_arr = split("\n",$arr['cont']);
		$return_2_str_arr = split(",",$return_str_arr[1]);
		$arr['cont'] = $return_2_str_arr[1];
		if($arr["code"] == 0 && $return_str_arr[0] == 0) {
			return array("code" => 0 , "num" => (int)$arr["cont"] );
		} else {
			switch($return_str_arr[0]) {
				case "30":
					$err = "密码错误";
					$code = 30;
					break;
				case "40":
					$err = "账号不存在";
					$code = 40;
					break;
				case "41":
					$err = "余额不足";
					$code = 41;
					break;
				case "42":
					$err = "账号过期";
					$code = 42;
					break;
				case "43":
					$err = "IP地址限制";
					$code = 43;
					break;
				case "50":
					$err = "内容含有敏感词";
					$code = 50;
					break;
				case "51":
					$err = "手机号码不正确";
					$code = 51;
					break;
				default:
					$err = "访问短信服务器出错";
					$code = 501;
			}
			return array("code" => $code , "msg" => $err , "num" => 0);
		}
	}

	//发送短信
	function on_send( $arr ) {
		if(!isset($arr["tel"]) || empty($arr["tel"])) {
			return array("code"=>500,"msg"=>"发送失败，电话号码为空");
		}
		if( !isset($arr["cont"]) && empty($arr["cont"]) ) {
			return array("code"=>500,"msg"=>"发送失败，短信内容为空");
		}
		//如果为测试环境，只允许测试手机号
		if(cls_config::IS_TEST>0) {
			$arr_allowtel = cls_config::get("test_tel" , "sms");
			if(!is_array($arr_allowtel) || !in_array($arr['tel'] , $arr_allowtel)) {
				return array("code" => 500 , "msg" => "该号码未开通测试权限");
			}
		}
		$count = cls_config::get("count_id" , "sms");
		$pwd = cls_config::get("count_pwd" , "sms");

		$arr_fields = array(
			"u" => $count,
			"p" => $pwd,
			"m" => $arr["tel"],
			"c" => $arr["cont"]
		);
		$arr_re = fun_base::post("http://api.smsbao.com/sms" , $arr_fields);
		$return_str = $arr_re['cont'];
		if($arr_re["code"] == 0 && $return_str == 0) {
			$arr_return = array("code" => 0 , "id" => 0 );
		} else {
			$arr_return = array("code" => 500 , "msg" => $this->result[$return_str] , "id" => 0);
		}
		if(!isset($arr["type"])) $arr["type"] = 0;
		if(!isset($arr["id"])) $arr["id"] = 0;
		if(!isset($arr["confirm_id"])) $arr["confirm_id"] = 0;
		$arr_fields = array(
			"sms_content" => $arr["cont"],
			"sms_tel" => $arr["tel"],
			"sms_type" => $arr["type"],
			"sms_addtime" => TIME,
			"sms_day" => date("Y-m-d H:i:s" , TIME),
			"sms_time" => date("Y-m-d" , TIME),
			"sms_about_id" => $arr['id'],
			"sms_confirm_id" => $arr['confirm_id']
		);
		tab_other_sms::on_save($arr_fields);
		return $arr_return;
	}

	//发送短信状态
	function get_sendstate() {
		return array("code" => 0 , "cont" => '成功');
	}

	//获取短信回复
	function get_recont() {
		return array("code"=>0 , "list" => $arr_list);
	}


}