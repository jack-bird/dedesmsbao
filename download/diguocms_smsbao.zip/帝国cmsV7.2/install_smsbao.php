<?php
/*
 * 帝国cms V7.2短信宝短信插件
 * Auth:linf
 * date:2017-03-13 13:44:43
 */
define('EmpireCMSAdmin','1');
require("e/class/connect.php");
require("e/class/db_sql.php");
require("e/class/functions.php");
$link=db_connect();
$empire=new mysqlquery();
//添加插件菜单
global $empire,$dbtbpre;
$sql=$empire->query("insert into {$dbtbpre}enewsmenuclass(classid,classname,myorder,classtype) values('99','短信插件','0','2');");
$sql_child_menu1=$empire->query("insert into {$dbtbpre}enewsmenu(menuname,menuurl,myorder,classid,addhash) values('短信账户设置','smsbao/SmsbaoConfig.php','0','99','1');");
$sql_child_menu2=$empire->query("insert into {$dbtbpre}enewsmenu(menuname,menuurl,myorder,classid,addhash) values('发送给会员','smsbao/SendToMember.php','0','99','1');");
$sql_child_menu3=$empire->query("insert into {$dbtbpre}enewsmenu(menuname,menuurl,myorder,classid,addhash) values('平台或商家手机号','smsbao/SendToConsignee.php','0','99','1');");
$sql_child_menu4=$empire->query("insert into {$dbtbpre}enewsmenu(menuname,menuurl,myorder,classid,addhash) values('发送给其他人','smsbao/SendToOther.php','0','99','1');");
$sql_child_menu5=$empire->query("CREATE TABLE `{$dbtbpre}rz` (`id` int(11) NOT NULL auto_increment,`bsm` varchar(255) NOT NULL,`rzm` varchar(255) NOT NULL,`sj` varchar(255) NOT NULL,`t` int(11) NOT NULL,`c` int(11) NOT NULL,PRIMARY KEY `id` (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
$sql_child_menu6=$empire->query("CREATE TABLE `{$dbtbpre}rzq` ( `id` int(11) NOT NULL auto_increment,`bsm` varchar(255) NOT NULL,`rzm` varchar(255) NOT NULL,`sj` varchar(255) NOT NULL,`t` int(11) NOT NULL,`c` int(11) NOT NULL,`username` char(20) NOT NULL, PRIMARY KEY `id` (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
if($sql&&$sql_child_menu1&&$sql_child_menu2&&$sql_child_menu3&&$sql_child_menu4&&$sql_child_menu5&&$sql_child_menu6){
	echo '短信宝短信插件安装成功，请删除系统根目录下的install_smsbao.php文件';
}else{
	echo '安装失败';
}
?>