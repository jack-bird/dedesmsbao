<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?>
<?php
$public_diyr['pagetitle']='取回密码';
$url="<a href=../../../>首页</a>&nbsp;>&nbsp;<a href=../cp/>会员中心</a>&nbsp;>&nbsp;取回密码";
require(ECMS_PATH.'e/template/incfile/header.php');
?>
<script src="/js/jquery.min-1.7.2.js"></script>
<br>
<table width="500" border="0" align="center" cellpadding="3" cellspacing="1" class="tableborder">
  <form name="GetPassForm" method="POST" action="../doaction.php">
    <tr class="header"> 
      <td height="25" colspan="2"><div align="center">取回密码</div></td>
    </tr>
    <tr bgcolor="#FFFFFF"> 
      <td width="23%" height="25">用户名</td>
      <td width="77%"><input name="username" type="text" id="username" size="38"></td>
    </tr>
    <tr bgcolor="#FFFFFF"> 
      <td height="25">手机</td>
      <td><input name="phone" type="text" id="phone" size="38"></td>
    </tr>
	<tr> 
      <td height="25" bgcolor="#FFFFFF"> <div align='left'>认证码</div></td>
      <td height="25" bgcolor="#FFFFFF"> <input name='rzm' type='text' id='rzm' maxlength='30'>
        *<input  type="button" style="font-size: 12px; height: 22px; line-height: 19px;" value="发送验证码" onclick="sendrzm()" id="sendag"  ></td>
    </tr>
	
    <tr bgcolor="#FFFFFF">
      <td height="25">验证码</td>
      <td><input name="key" type="text" id="key" size="6"> <img src="../../ShowKey/?v=getpassword" name="getpasswordKeyImg" id="getpasswordKeyImg" onclick="getpasswordKeyImg.src='../../ShowKey/?v=getpassword&t='+Math.random()" title="看不清楚,点击刷新"></td>
    </tr>
    <tr bgcolor="#FFFFFF"> 
      <td height="25">&nbsp; </td>
      <td> <input type="submit" name="button" value="提交"> <input name="enews" type="hidden" id="enews" value="SendPassword"></td>
    </tr>
  </form>
</table>

<SCRIPT language=javascript>
<!--
var secs = 120;
function sendrzm(){
     var tel=$("#phone").val();
	 var un=$("#username").val();
     $.getJSON('/e/member/doaction.php?enews=Rzsjq&phone=' + tel + '&username=' + un,
        function(data) {
            if(data.d=='2'){
			    alert(data.n);
			}else{
			    document.GetPassForm.sendag.disabled=true;
                for(i=1;i<=secs;i++) {
                 window.setTimeout("update(" + i + ")", i * 1000);
                }
			}
           
        });
		
  
}
function update(num) {
 if(num == secs) {
 document.GetPassForm.sendag.value ="重新发送认证码";
 document.GetPassForm.sendag.disabled=false;
 }
else {
 printnr = secs-num;
 document.GetPassForm.sendag.value = "(" + printnr +")重新发送认证码";
 }
}
//-->
</SCRIPT>
<br>
<?php
require(ECMS_PATH.'e/template/incfile/footer.php');
?>