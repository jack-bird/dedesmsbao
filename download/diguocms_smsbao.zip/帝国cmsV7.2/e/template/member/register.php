<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?>
<?php
$public_diyr['pagetitle']='注册会员';
$url="<a href=../../../>首页</a>&nbsp;>&nbsp;<a href=../cp/>会员中心</a>&nbsp;>&nbsp;注册会员";
require(ECMS_PATH.'e/template/incfile/header.php');
?>
<table width='100%' border='0' align='center' cellpadding='3' cellspacing='1' class="tableborder">
  <form name=userinfoform method=post enctype="multipart/form-data" action=../doaction.php>
    <input type=hidden name=enews value=register>
    <tr class="header"> 
      <td height="25" colspan="2">注册会员<?=$tobind?' (绑定账号)':''?></td>
    </tr>
    <tr> 
      <td height="25" colspan="2"><strong>基本信息 
        <input name="groupid" type="hidden" id="groupid" value="<?=$groupid?>">
        <input name="tobind" type="hidden" id="tobind" value="<?=$tobind?>">
      </strong></td>
    </tr>
    <tr> 
      <td width='25%' height="25" bgcolor="#FFFFFF"> <div align='left'>用户名</div></td>
      <td width='75%' height="25" bgcolor="#FFFFFF"> <input name='username' type='text' id='username' maxlength='30'>
        *</td>
    </tr>
    <tr> 
      <td height="25" bgcolor="#FFFFFF"> <div align='left'>密码</div></td>
      <td height="25" bgcolor="#FFFFFF"> <input name='password' type='password' id='password' maxlength='20'>
        *</td>
    </tr>
    <tr> 
      <td height="25" bgcolor="#FFFFFF"> <div align='left'>重复密码</div></td>
      <td height="25" bgcolor="#FFFFFF"> <input name='repassword' type='password' id='repassword' maxlength='20'>
        *</td>
    </tr>
    <tr> 
      <td height="25" bgcolor="#FFFFFF"> <div align='left'>邮箱</div></td>
      <td height="25" bgcolor="#FFFFFF"> <input name='email' type='text' id='email' maxlength='50'>
        *</td>
    </tr>
	<?
	if($public_r['regkey_ok'])
	{
	?>
    <tr>
      <td height="25" bgcolor="#FFFFFF">验证码：</td>
      <td height="25" bgcolor="#FFFFFF"><input name="key" type="text" id="key" size="6"> 
        <img src="../../ShowKey/?v=reg" name="regKeyImg" id="regKeyImg" onclick="regKeyImg.src='../../ShowKey/?v=reg&t='+Math.random()" title="看不清楚,点击刷新"></td>
    </tr>
	<?
	}	
	?>
	<tr> 
      <td height="25" bgcolor="#FFFFFF"> <div align='left'>手机号码</div></td>
      <td height="25" bgcolor="#FFFFFF"> <input name='phone' type='text' id='phone' maxlength='50'>
        *</td>
    </tr>
	<tr> 
      <td height="25" bgcolor="#FFFFFF"> <div align='left'>验证码</div></td>
      <td height="25" bgcolor="#FFFFFF"> <input name='rzm' type='text' id='rzm' maxlength='30'>
        *<input  type="button" style="font-size: 12px; height: 22px; line-height: 19px;" value="发送验证码" onclick="sendrzm()" id="sendag"  ></td>
    </tr>
    <tr> 
      <td height="25" colspan="2"><strong>其他信息</strong></td>
    </tr>
    <tr> 
      <td height="25" colspan="2" bgcolor="#FFFFFF"> 
    <?php
	@include($formfile);
	?>
      </td>
    </tr>
    <tr> 
      <td height="25" bgcolor="#FFFFFF">&nbsp;</td>
      <td height="25" bgcolor="#FFFFFF"> <input type='submit' name='Submit' value='马上注册'> 
        &nbsp;&nbsp; <input type='button' name='Submit2' value='返回' onclick='history.go(-1)'></td>
    </tr>
    <tr bgcolor="#FFFFFF"> 
      <td height="25" colspan="2">说明：带*项为必填。</td>
    </tr>
  </form>
</table>
<script src="/js/jquery.min-1.7.2.js"></script>
<SCRIPT language=javascript>
<!--
var secs = 120;
function sendrzm(){
     var tel=$("#phone").val();
	 <?
	if($public_r['regkey_ok'])
	{
	?>
		if($('#key').val()==''||$('#key').val().length<4){
			alert('请先填写图形验证码');
			return false;
		}
	<?
	}	
	?>
    if($.trim(tel)==''||$.trim(tel).length!=11){
		alert('请填写正确的手机号码');
	}else{
		$.getJSON('/e/member/doaction.php?enews=Rzsj&phone=' + tel + '',
			function(data) {
				if(data.d=='2'){
					alert(data.n);
				}else{
					document.userinfoform.sendag.disabled=true;
								for(i=1;i<=secs;i++) {
								 window.setTimeout("update(" + i + ")", i * 1000);
								}
				}
							 
			});
	}
    
}
function update(num) {
 if(num == secs) {
 document.userinfoform.sendag.value ="重新发送验证码";
 document.userinfoform.sendag.disabled=false;
 }
else {
 printnr = secs-num;
 document.userinfoform.sendag.value = "(" + printnr +")重新发送验证码";
 }
}
//-->
</SCRIPT>
<?php
require(ECMS_PATH.'e/template/incfile/footer.php');
?>