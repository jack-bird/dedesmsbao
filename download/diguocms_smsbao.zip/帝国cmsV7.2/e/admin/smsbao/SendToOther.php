<?php
define('EmpireCMSAdmin','1');
require("../../class/connect.php");
require("../../class/db_sql.php");
require("../../class/functions.php");
require("Smsbao.php");
$link=db_connect();
$empire=new mysqlquery();
$editor=1;
//验证用户
$lur=is_login();
$logininid=$lur['userid'];
$loginin=$lur['username'];
$loginrnd=$lur['rnd'];
$loginlevel=$lur['groupid'];
$loginadminstyleid=$lur['adminstyleid'];
//ehash
$ecms_hashur=hReturnEcmsHashStrAll();
//验证权限
CheckLevel($logininid,$loginin,$classid,"gbook");
//取出短信配置信息
$smsbao_config=file_get_contents("config.txt");
$smsbao_config=explode(",", $smsbao_config); 
if($_POST){
	//如果提交了表单
	if($_POST['sms_mobiles']==''){
		//如果没有填写手机号
		echo "<script>alert('请先填写要发送的手机号');</script>";
	}elseif($_POST['sms_content']==''){
		//如果没有填写短信内容
		echo "<script>alert('请填写要发送的短信内容');</script>";
	}else{
		$smsbao=new Sms($smsbao_config[0],$smsbao_config[1]);
		$mobiles=explode(',',trim($_POST['sms_mobiles']));
		$mobiles=array_unique($mobiles);
		$mobile_count=count($mobiles);
		$success_count=0;
		$failed_count=0;
		$content="【".$smsbao_config[2]."】".trim($_POST['sms_content']);
		foreach($mobiles as $key=>$val){
			$sms_res=$smsbao->sendSms($val,$content);
			if($sms_res=='0'){
				$success_count++;
			}else{
				$failed_count++;
			}
		}
		echo "<script>alert('{$mobile_count}个手机号码，发送成功{$success_count}个，失败{$failed_count}个！');</script>";
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="../adminstyle/<?=$loginadminstyleid?>/adminstyle.css" rel="stylesheet" type="text/css">
<style>
.sms{width:400px;height:200px;line-height:20px;}
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr>
    <td>位置：<a href="SendToOther.php<?=$ecms_hashur['whehref']?>">发送给其他人</a>&nbsp;&nbsp;</td>
  </tr>
</table>
<form name="form1" method="post" action="SendToOther.php">
  <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="tableborder">
  <?=$ecms_hashur['form']?>
    <tr class="header">
      <td height="25">发送给其他人: 
        <input name=enews type=hidden id="enews" value=AddGbookClass>
        </td>
    </tr>
    <tr> 
      <td height="25" bgcolor="#FFFFFF"> 手机号码: </br>
        <textarea name="sms_mobiles" class="sms"></textarea> 填写手机号码，多个手机号码之前用英文逗号,隔开
        </td>
    </tr>
	<tr> 
      <td height="25" bgcolor="#FFFFFF"> 短信内容: </br>
       <textarea name="sms_content" class="sms"></textarea> 填写要发送的短信内容
        </td>
    </tr>
	<tr>
		<td>
			<input type="submit" name="Submit" value="发送">
		</td>
	</tr>
  </table>
</form>
<?
db_close();
$empire=null;
?>
</body>
</html>
