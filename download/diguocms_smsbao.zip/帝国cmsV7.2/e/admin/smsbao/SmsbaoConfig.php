<?php
define('EmpireCMSAdmin','1');
require("../../class/connect.php");
require("../../class/db_sql.php");
require("../../class/functions.php");
$link=db_connect();
$empire=new mysqlquery();
$editor=1;
//验证用户
$lur=is_login();
$logininid=$lur['userid'];
$loginin=$lur['username'];
$loginrnd=$lur['rnd'];
$loginlevel=$lur['groupid'];
$loginadminstyleid=$lur['adminstyleid'];
//ehash
$ecms_hashur=hReturnEcmsHashStrAll();
//验证权限
CheckLevel($logininid,$loginin,$classid,"gbook");
//取出短信配置信息
$smsbao_config=file_get_contents("config.txt");
$smsbao_config=explode(",", $smsbao_config); 
//保存短信配置信息
if($_POST){
	if($_POST['sms_name']==''||$_POST['sms_password']==''||$_POST['sms_sign']==''){
		echo "<script>alert('参数不完整');</script>";
	}else{
		hCheckEcmsRHash();
		$content=trim($_POST['sms_name']).",".trim($_POST['sms_password']).",".trim($_POST['sms_sign']);
		if(file_put_contents("config.txt",$content)){
			echo "<script>alert('保存成功');</script>";
		}else{
			echo "<script>alert('保存失败');</script>";
		}
		
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="../adminstyle/<?=$loginadminstyleid?>/adminstyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr>
    <td>位置：<a href="SmsbaoConfig.php<?=$ecms_hashur['whehref']?>">短信账户设置</a>&nbsp;&nbsp;</td>
  </tr>
</table>
<form name="form1" method="post" action="SmsbaoConfig.php">
  <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="tableborder">
  <?=$ecms_hashur['form']?>
    <tr class="header">
      <td height="25">填写短信配置信息: 
        <input name=enews type=hidden id="enews" value=AddGbookClass>
        </td>
    </tr>
    <tr> 
      <td height="25" bgcolor="#FFFFFF"> 账号: 
        <input name="sms_name" value="<?php echo $smsbao_config[0]?>" type="text" id="sms_name"> 填写短信宝账号用户名，还没有短信宝账号？点击<a href="http://www.smsbao.com" target="_blank">免费注册</a>
        </td>
    </tr>
	<tr> 
      <td height="25" bgcolor="#FFFFFF"> 密码: 
        <input name="sms_password" value="<?php echo $smsbao_config[1]?>" type="password" id="sms_password"> 短信宝账号密码
        </td>
    </tr>
	<tr> 
      <td height="25" bgcolor="#FFFFFF"> 签名: 
        <input name="sms_sign" value="<?php echo $smsbao_config[2]?>" type="text" id="sms_sign"> 短信的签名，如：帝国cms
        </td>
    </tr>
	<tr>
		<td>
			<input type="submit" name="Submit" value="保存">
			<input type="reset" name="Submit2" value="重置">
		</td>
	</tr>
  </table>
</form>

</body>
</html>
