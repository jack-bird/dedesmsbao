<?php
define('EmpireCMSAdmin','1');
require("../../class/connect.php");
require("../../class/db_sql.php");
require("../../class/functions.php");
$link=db_connect();
$empire=new mysqlquery();
$editor=1;
//验证用户
$lur=is_login();
$logininid=$lur['userid'];
$loginin=$lur['username'];
$loginrnd=$lur['rnd'];
$loginlevel=$lur['groupid'];
$loginadminstyleid=$lur['adminstyleid'];
//ehash
$ecms_hashur=hReturnEcmsHashStrAll();
//验证权限
CheckLevel($logininid,$loginin,$classid,"gbook");
//取出商家手机号配置信息
$smsbao_config1=file_get_contents("shop.txt");
$smsbao_config=explode(",", $smsbao_config1); 
//保存商家手机号配置信息
if($_POST){
	if($_POST['sms_mobile']==''){
		echo "<script>alert('参数不完整');</script>";
	}else{
		hCheckEcmsRHash();
		$content=trim($_POST['sms_mobile']);
		if(file_put_contents("shop.txt",$content)){
			echo "<script>alert('保存成功');</script>";
		}else{
			echo "<script>alert('保存失败');</script>";
		}
		
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="../adminstyle/<?=$loginadminstyleid?>/adminstyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr>
    <td>位置：<a href="SendToConsignee.php<?=$ecms_hashur['whehref']?>">平台或商家手机号</a>&nbsp;&nbsp;</td>
  </tr>
</table>
<form name="form1" method="post" action="SendToConsignee.php">
  <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="tableborder">
  <?=$ecms_hashur['form']?>
    <tr class="header">
      <td height="25">填写商家手机号: 
        <input name=enews type=hidden id="enews" value=AddGbookClass>
        </td>
    </tr>
    <tr> 
      <td height="25" bgcolor="#FFFFFF"> 手机号: 
        <input name="sms_mobile" value="<?php echo $smsbao_config1?>" type="text" id="sms_mobile" style="width:300px;"> 用于新订单、留言、投稿时短信通知商家，多个商家的手机号请用英文逗号,隔开
        </td>
    </tr>
	<tr>
		<td>
			<input type="submit" name="Submit" value="保存">
			<input type="reset" name="Submit2" value="重置">
		</td>
	</tr>
  </table>
</form>

</body>
</html>
