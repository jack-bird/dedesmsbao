<?php
define('IN_HHS', true);
require(dirname(__FILE__) . '/includes/init.php');

$sql = "INSERT INTO `hhs_shop_config` VALUES ('', '9999', 'sms_sign', 'text', '', '', 'smsbao', '1')";
if(!$query = $db->query($sql)) {
		echo "执行sql语句成功 ".mysql_error();
		exit();
}

echo "<h4>短信宝短信插件安装成功，请删除您网站根目录下的install_smsbao.php文件</h4>";


?>