<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>思途CMS{$coreVersion}</title>
    {template 'stourtravel/public/public_min_js'}
    {php echo Common::getScript("DatePicker/WdatePicker.js,config.js"); }
    {php echo Common::getCss('base.css,sms_dialog.css,style.css'); }
</head>
<body >
   <div class="s-main">
        <div class="set-con">
            <div class="msg-tc">
                <div class="tit" style="height: auto">
                    <ul>
                        <li class="bt">购买说明</li>
                        <li>-请使用短信宝帐号登陆购买，还没有短信宝账户，请点击<a href="http://smsbao.com/reg" target="_blank" style="color:#0C7CE0;">免费注册</a></li>
                        <li>-短信宝客服热线：400-716-3021，或联系短信宝<a href="http://wpa.b.qq.com/cgi/wpa.php?ln=1&key=XzkzODA0NjAyMV8yNTU0MzFfNDAwMDA5MDQ2NV8yXw" target="_blank" style="color:#0C7CE0;">在线客服</a></li>
                        <li>-说明：欲购买1W条以上的短信套餐以及包月套餐用户，请咨询<a href="http://wpa.b.qq.com/cgi/wpa.php?ln=1&key=XzkzODA0NjAyMV8yNTU0MzFfNDAwMDA5MDQ2NV8yXw" target="_blank" style="color:#0C7CE0;">在线客服</a></li>
                        <li>-备注：短信宝官网（http://www.smsbao.com），短信宝技术交流群：188145230</li>
                    </ul>
                </div>
                <div class="con-list">
                    <dl>
                        <dt>A套餐</dt>
                        <dd>50条</dd>
                        <dd>5元</dd>
                        <dd class="bor-0"><a href="http://www.smsbao.com/member/product/list.jhtml" target="_blank" class="buybtn" data-suit="E">购买</a></dd>
                    </dl>
                    <dl>
                        <dt>B套餐</dt>
                        <dd>500条</dd>
                        <dd>40元</dd>
                        <dd class="bor-0 "><a  href="http://www.smsbao.com/member/product/list.jhtml" target="_blank" class="buybtn" data-suit="F">购买</a></dd>
                    </dl>
                    <dl>
                        <dt>C套餐</dt>
                        <dd>2000条</dd>
                        <dd>150元</dd>
                        <dd class="bor-0"><a  href="http://www.smsbao.com/member/product/list.jhtml" target="_blank" class="buybtn" data-suit="G">购买</a></dd>
                    </dl>
                    <dl>
                        <dt>D套餐</dt>
                        <dd>5000条</dd>
                        <dd>375元</dd>
                        <dd class="bor-0"><a  href="http://www.smsbao.com/member/product/list.jhtml" target="_blank" class="buybtn" data-suit="H">购买</a></dd>
                    </dl>
                    <dl>
                        <dt>E套餐</dt>
                        <dd>10000条</dd>
                        <dd>700元</dd>
                        <dd class="bor-0"><a  href="http://www.smsbao.com/member/product/list.jhtml" target="_blank" class="buybtn" data-suit="I">购买</a></dd>
                    </dl>
                    <dl>
                        <dt>F套餐</dt>
                        <dd>>10000条</dd>
                        <dd>？元</dd>
                        <dd class="bor-0"><a  href="http://wpa.b.qq.com/cgi/wpa.php?ln=1&key=XzkzODA0NjAyMV8yNTU0MzFfNDAwMDA5MDQ2NV8yXw" target="_blank" class="buybtn" data-suit="J">联系客服</a></dd>
                    </dl>
                    <dl>
                        <dt>包月套餐</dt>
                        <dd>？条</dd>
                        <dd>？元</dd>
                        <dd class="bor-0"><a href="http://wpa.b.qq.com/cgi/wpa.php?ln=1&key=XzkzODA0NjAyMV8yNTU0MzFfNDAwMDA5MDQ2NV8yXw" target="_blank" class="buybtn" data-suit="K">联系客服</a></dd>
                    </dl>

                </div>
            </div>
        </div>
   </div>

<script>
    //$(document).ready(function(){
        //$(".buybtn").click(function(){
           // var suit = $(this).attr('data-suit');
           // var payurl = "";
           // $.ajax({
           //     type: "post",
           //     data:{suittype:suit},
           //     url: SITEURL+"sms/buysms",
           //     async:false,
           //     dataType:'json',
           //     success:function(data){
			//
            //        if(data.status==0)
            //        {
            //            ST.Util.showMsg(data.msg,5,3000);
            //        }
            //        else if(data.status==1)
            //        {
            //            payurl = data.payurl
//
          //          }
          //      }
          //  })

          //  if(payurl!='')
          //  {
          //      window.open(payurl);//支付页面
          //  }
       // })

    //});
</script>
</body>
</html>
