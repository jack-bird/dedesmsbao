<?php
define('hopedir', dirname(__FILE__).DIRECTORY_SEPARATOR);
define('smsbao_use_core', dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lib/core/extend/Config.php');
define('smsbao_use_file', dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lib/core/extend/IFile.php');

require(smsbao_use_core);
require(smsbao_use_file);

header("Content-type: text/html; charset=utf-8");

$siteinfo = array();
$config = new Config('hopeconfig.php', hopedir);

$siteinfo['sms86ac'] = 'smsbaouser';
$siteinfo['sms86pd'] = 'smsbaouser';
$siteinfo['smstype'] = '1';
$siteinfo['mobileinterface'] = '短信宝';
$config->write($siteinfo);

echo '短信宝插件安装成功，请删除根目录下的install.php文件。如果有任何疑问，请访问<a href="http://www.smsbao.com/help/">短信宝官网</a>了解更多。';
