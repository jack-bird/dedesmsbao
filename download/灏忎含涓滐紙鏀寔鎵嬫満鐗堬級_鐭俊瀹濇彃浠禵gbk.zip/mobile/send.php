<?php
header("Content-Type:text/html;charset=utf-8");
/*--------------------------------
功能:HTTP接口 发送短信
修改日期:	2009-04-08
说明:		http://api.smsbao.com/sms?u=用户账号&p=密码&m=号码&c=内容
状态:
0:发送成功
-1：参数不全
30：密码错误
40：账号不存在
41：余额不足
42：帐号过期
43：IP地址限制
50：内容含有敏感词
51：手机号码不正确
--------------------------------*/
//$u = '9999';		//用户账号
//$p = '9999';		//密码
//$m	 = '13912341234,13312341234,13512341234,02122334444';	//号码
//$c = '你好，验证码：1019【云信】';		//内容
//即时发送
//$res = sendSMS($uid,$pwd,$mobile,$content);
//echo $res;

//定时发送
/*
$time = '2010-05-27 12:11';
$res = sendSMS($uid,$pwd,$mobile,$content,$time);
echo $res;
*/
function sendSMS ($mobile, $content, $time = '', $mid = '')
{
	//$content = iconv('gbk', 'utf-8', $content);
	$http = 'http://api.smsbao.com/sms?'; // 短信接口
	//获取一下短信宝的账户和用户名
	$sql_name = 'SELECT * FROM ' . $GLOBALS['ecs']->table('shop_config').
           " WHERE code = 'smsbao_user_name'";
    $user_name = $GLOBALS['db']->getRow($sql_name);
	$uid = $user_name['value']; // 用户账号
	$sql_pass = 'SELECT * FROM ' . $GLOBALS['ecs']->table('shop_config').
           " WHERE code = 'smsbao_pass_word'";
    $user_pass = $GLOBALS['db']->getRow($sql_pass);
	$pwd = $user_pass['value']; // 密码
	
	$data = array(
		'u' => $uid, // 用户账号
		'p' => strtolower(md5($pwd)), // MD5位32密码,密码和用户名拼接字符
		'm' => $mobile, // 号码
		'c' => iconv('gbk', 'utf-8', $content), // 内容
		't' => $time // 定时发送
	);
	$re = postSMS($http, $data); // POST方式提交
	                             
	// change_sms change_start
	
	//$re_t = substr(trim($re), 3, 3);
	//return $re;
	if(trim($re) == '0')
	
	// change_sms change_end
	
	{
		return true;
	}
	else
	{
		return false;
	}
}

function postSMS ($url, $data = '')
{
	return file_get_contents($url.http_build_query($data));
}
?>