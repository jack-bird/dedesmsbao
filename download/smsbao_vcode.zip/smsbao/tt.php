<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/9/27
 * Time: 9:59
 */
?>
<script>
var time = 0; // 倒计时时间
var res = null; // 倒计时资源，释放时使用
var sendNode = null; // 发送的按钮节点
var diffTime = "<?php echo $diff; ?>"; // 由php计算的时间差

/**
 * 执行倒计时的方法
 */
function sendTime() {
    clearTimeout(res); // 先清空一下倒计时资源。
    time--; // 倒计时时间递减。

    // 如果倒计时到达0时，则恢复按钮原来的内容
    if (time <= 0) {
        time = "获取验证码";
        sendNode.text(time);
        clearTimeout(res);
        time = 0;
        return;
    }

    // 倒计时的内容写到按钮里面
    sendNode.text("剩余" + time + "秒");
    res = setTimeout("sendTime()", 1000);
}

/**
 * 调用处
 */
$(function() {
    sendNode = $("#get_code"); // 获取发送的节点
    var flg = true; // 防止ajax重复提交的标记

    // 在页面加载时，先判断一下是否上次倒计时未完成，由php计算，防止页面刷新，覆盖掉倒计时。
    if ("" != diffTime) {
        time = parseInt(diffTime);
        sendTime();
    }

    /**
     * 点击发送短信，触发事件
     */
    sendNode.on("click", function() {
        // 如果当前倒计时结束，则收集表单数据，并ajax提交到服务端
        if (0 == time) {
            var phoneNum = $("input[name='phone']").val();
            var code = $("input[name='vcode']").val();
            var data = {"code" : code, "phone" : phoneNum};
            var err = "";

            if (flg == true) {
                flg = false;

                $.ajax({
                    "url" : "./tool/sendCode.php",
                    "type" : "post",
                    "data" : data,
                    "dataType" : "json",
                    "success" : function (msg) {
                    $(".errmsg").text("");

                    if (-1 == msg.flg) {
                        err = msg.err;

                        if ("code" == msg.type) {
                            $("#code_err").text(err);
                        } else if ("phone" == msg.type) {
                            $("#phone_err").text(err);
                        } else {
                            alert("短信发送失败，原因：" + err);
                        }
                    } else {
                        time = 60;
                        sendTime();
                        alert("发送验证码成功！");
                    }

                    $("#code_img").click();
                    flg = true;
                }
                });
            }
            return false;
        }
    });
});
    </script>

