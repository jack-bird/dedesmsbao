<?php
return array(
    'smsbao_name' => 'smsbaouser', // 您的短信宝账号
    'smsbao_password' => 'smsbaopassword', // 您的短信宝密码
);