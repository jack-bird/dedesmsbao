<?php
session_start(); // 开启session会话
require('./Code.php'); // 引入验证码类文件
$code = new Code(); // 实例化
$code->make(); // 调用验证码显示方法来显示