<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/8/29
 * Time: 9:35
 */
class Helpers
{
    /**
     * 去除两端空格
     *
     * @param $data
     * @return array
     */
    public static function removeSpaces($data)
    {
        if (is_array($data) && !empty($data)) {
            foreach ($data as $key => $item) {
                $data[$key] = trim($item);
            }
        }

        return $data;
    }

    public static function dd($data)
    {
        if (is_array($data) || is_object($data)) {
            echo '<pre>';
            print_r($data);
            echo '</pre>';
        } else {
            var_dump($data);
        }

        exit;
    }
}