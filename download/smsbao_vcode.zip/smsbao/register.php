<?php
// 开启session
session_start();
// 引入工具类
require('tool/CheckTool.php');
require('tool/Helpers.php');

$diff = '';

// 得到上次短信请求时间，和当前时间做对比。
if (isset($_SESSION['send_time']) && is_int($_SESSION['send_time'])) {
    $currentTime = time();
    $diff = $currentTime - $_SESSION['send_time'];
    $diff = $diff < 60 ? 60 - $diff : '';
}

// 获取表单数据，进行验证，成功后跳转到登入页面。
if (!empty($_POST['is_send'])) {
    $data = Helpers::removeSpaces($_POST);
    $res = CheckTool::exec($data);

    if (!is_array($res) && true === $res) {
        // 清除记录的验证码和手机号码
        $_SESSION['sms_code'] = null;
        $_SESSION['send_phone'] = null;
        unset($_SESSION['sms_code']);
        unset($_SESSION['send_phone']);
        header("Location:login.php");
        exit();
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        * {margin:0; padding:0;}
        h1 {margin:30px 0 25px 0;}
        .form-input {margin-bottom:10px;}
        .form-input input {width:200px; height:25px;}
        .form-input button {width:60px; height:25px;}
        #main {width:500px; margin:0 auto;}
        #vcode {width:80px;}

        #phone_code {width:80px;}
        .code_label {position:relative;}
        .code_label img {position:absolute; top:-5px; left:185px; cursor: pointer;}
        .code_label button {width:90px; cursor: pointer;}
    </style>
<script src="js/jquery.js"></script>
<script>
    var time = 0; // 倒计时时间
    var res = null; // 倒计时资源，释放时使用
    var sendNode = null; // 发送的按钮节点
    var diffTime = "<?php echo $diff; ?>"; // 由php计算的时间差

    /**
     * 执行倒计时的方法
     */
    function sendTime() {
        clearTimeout(res); // 先清空一下倒计时资源。
        time--; // 倒计时时间递减。

        // 如果倒计时到达0时，则恢复按钮原来的内容
        if (time <= 0) {
            time = "获取验证码";
            sendNode.text(time);
            clearTimeout(res);
            time = 0;
            return;
        }

        // 倒计时的内容写到按钮里面
        sendNode.text("剩余" + time + "秒");
        res = setTimeout("sendTime()", 1000);
    }

    /**
     * 调用处
     */
    $(function() {
        sendNode = $("#get_code"); // 获取发送的节点
        var flg = true; // 防止ajax重复提交的标记

        // 在页面加载时，先判断一下是否上次倒计时未完成，由php计算，防止页面刷新，覆盖掉倒计时。
        if ("" != diffTime) {
            time = parseInt(diffTime);
            sendTime();
        }

        /**
         * 点击发送短信，触发事件
         */
        sendNode.on("click", function() {
            // 如果当前倒计时结束，则收集表单数据，并ajax提交到服务端
            if (0 == time) {
                var phoneNum = $("input[name='phone']").val();
                var code = $("input[name='vcode']").val();
                var data = {"code" : code, "phone" : phoneNum};
                var err = "";

                if (flg == true) {
                    flg = false;
                    // ajax提交请求
                    $.ajax({
                        "url" : "./tool/sendCode.php",
                        "type" : "post",
                        "data" : data,
                        "dataType" : "json",
                        "success" : function (msg) {
                            $(".errmsg").text("");

                            if (-1 == msg.flg) {
                                err = msg.err;

                                if ("code" == msg.type) {
                                    $("#code_err").text(err);
                                } else if ("phone" == msg.type) {
                                    $("#phone_err").text(err);
                                } else {
                                    alert("短信发送失败，原因：" + err);
                                }
                            } else {
                                time = 60;
                                sendTime();
                                alert("发送验证码成功！");
                            }
                            // 刷新图形验证码
                            $("#code_img").click();
                            flg = true;
                        }
                    });
                }
                return false;
            }
        });
    });
</script>
</head>
<body>
<div id="main">
    <h1>用户注册</h1>
    <form method="post" action="register.php">
        <div class="form-input">
            <label>
                手机号码&emsp;
                <input type="text" name="phone" value="<?php echo isset($_POST['phone']) ? $_POST['phone'] : ''; ?>"/>
                <p id="phone_err" class="errmsg" style="margin:5px 0 0 88px; color:red;"><?php echo isset($res['phone']) ? $res['phone'] : ''; ?></p>
            </label>
        </div>
        <div class="form-input">
            <label>
                密&emsp;&emsp;码&emsp;
                <input type="password" name="password" value="<?php echo isset($_POST['password']) ? $_POST['password'] : ''; ?>"/>
                <p id="phone_err" class="errmsg" style="margin:5px 0 0 88px; color:red;"><?php echo isset($res['password']) ? $res['password'] : ''; ?></p>
            </label>
        </div>
        <div class="form-input">
            <label>
                确认密码&emsp;
                <input type="password" name="repassword" value=""/>
            </label>
        </div>

        <div class="form-input">
            <label class="code_label">
                验&ensp;证&ensp;码&emsp;
                <input id="vcode" type="text" name="vcode" value=""/>
                <img id="code_img" src="./tool/show_code.php" onclick="this.src='./tool/show_code.php?'+Math.random()" />
                <p id="code_err" class="errmsg" style="margin:5px 0 0 88px; color:red;"></p>
            </label>
        </div>
        <div class="form-input">
            <label class="code_label">
                手机验证码
                <input id="phone_code" type="text" name="code" value="<?php echo isset($_POST['code']) ? $_POST['code'] : ''; ?>"/>
                <button type="button" id="get_code">获取验证码</button>
                <p id="phone_err" class="errmsg" style="margin:5px 0 0 88px; color:red;"><?php echo isset($res['code']) ? $res['code'] : ''; ?></p>
            </label>
        </div>
        <input type="hidden" name="is_send" value="1"/>
        <div class="form-input">
            <label>
                <button type="submit">提 交</button>
            </label>
        </div>
    </form>
</div>

</body>
</html>
