<?php

define('IN_ECS', true);

require(dirname(__FILE__) . '/includes/init.php');
//在languages/zh_cn/admin/shop_config.php文件中引入短信宝的相关配置信息
$write_dir=(dirname(__FILE__) . '/languages');
$file_name_zh_cn=(dirname(__FILE__) . '/languages/zh_cn/admin/shop_config.php');
$file_name_en_us=(dirname(__FILE__) . '/languages/en_us/admin/shop_config.php');
$file_name_zh_tw=(dirname(__FILE__) . '/languages/zh_tw/admin/shop_config.php');
$add_content_zh_cn="<?php require(ROOT_PATH.'/languages/zh_cn/admin/shop_config_smsbao.php'); ?>";
$add_content_en_us="<?php require(ROOT_PATH.'/languages/en_us/admin/shop_config_smsbao.php'); ?>";
$add_content_zh_tw="<?php require(ROOT_PATH.'/languages/zh_tw/admin/shop_config_smsbao.php'); ?>";
//开始引入
	$myfile_zh_cn = fopen($file_name_zh_cn, "a") or die("Unable to open file!");
    $txt_zh_cn= $add_content_zh_cn;
    fwrite($myfile_zh_cn, $txt_zh_cn);
    fclose($myfile_zh_cn);
	$myfile_en_us = fopen($file_name_en_us, "a") or die("Unable to open file!");
    $txt_en_us= $add_content_en_us;
    fwrite($myfile_en_us, $txt_en_us);
    fclose($myfile_en_us);
	$myfile_zh_tw = fopen($file_name_zh_tw, "a") or die("Unable to open file!");
    $txt_zh_tw= $add_content_zh_tw;
    fwrite($myfile_zh_tw, $txt_zh_tw);
    fclose($myfile_zh_tw);
	echo "<h4>短信宝配置完毕</h4>";

$newsql = sreadfile("install_smsbao.sql");

if($prefix != 'ecs_') 
	$newsql = str_replace('ecs_', $prefix, $newsql);//替换表前缀

$sqls = explode(";", $newsql);
foreach ($sqls as $sql) {
	$sql = trim($sql);
	if (empty($sql)) {
		continue;
	}
	if(!$query = $db->query($sql)) {
		echo "执行sql语句成功 ".mysql_error();
		exit();
	}
}

echo "<h4>小京东短信宝短信插件安装成功，请删除您网站根目录下的install_smsbao.php和install_smsbao.sql文件。</h4>";

function sreadfile($filename) {
	$content = '';
	if(function_exists('file_get_contents')) {
		@$content = file_get_contents($filename);
	} else {
		if(@$fp = fopen($filename, 'r')) {
			@$content = fread($fp, filesize($filename));
			@fclose($fp);
		}
	}
	return $content;
}

?>