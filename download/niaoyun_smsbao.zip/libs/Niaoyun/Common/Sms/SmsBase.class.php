<?php

namespace Niaoyun\Common\Sms;

use Org\Net\Curl;
use Niaoyun\Common\Sms;


class SmsBase extends Sms{


	public $config; // 接口配置

	protected $mobile; // 手机号
	protected $content; // 内容

	public $api; // 接口名
	public $url; // 接口地址

	public $params; // 请求参数
	public $headers = null; // 请求头

	public $status;
	public $result;
	public $rawResult; // 请求原始结果

	public $error; // 错误信息
	public $errno; // 错误码

	public $errorArr; // 错误配置，在各个子类中


	public function __construct($code){
		$this->platformCode = $code;
		$this->setConfig();
	}

	public function post(){
		$this->rawResult = Curl::post($this->url, $this->params, $this->headers);
	}

	public function setConfig(){
		$this->config = $this->getConfig();
	}

	public function getConfig(){
		$config = null;
		switch($this->platformCode){
			case '2office':
				$smgData=C('smg');
				$config = array(
					'url' => 'http://sms.2office.net:8080/WebService/SmsService.asmx',
					'account' => $smgData['smgAcount'],
					'password' => $smgData['smgPassword2'],
					'authCode' => $smgData['smgAuthCode'],
					'channel' => $smgData['smgChannel'],
					'sendType' => '1',
					'signature' => $smgData['smgSignature'], // 短信内容签名
				);
				break;
			case 'entinfo':
				$smgData=C('smg');
				$config = array(
					'url' => 'http://api.smsbao.com/sms',
					'apiId' =>$smgData['smgApiId'],
					'apiKey' => $smgData['smgApiKey'], 
					'signature' =>$smgData['smgSignatureMd'],
				);
				break;
		}
		return $config;
	}

	public function sendSetup($mobile, $content, $id){

		$this->setMobile($mobile);
		$this->setContent($content);
		$this->setMessageId($id); // id 由控制类生成

		$this->setUrl();
		$this->setParams();
		$this->setHeaders();

	}

	protected function processBalanceResult(){
		$res = simplexml_load_string($this->rawResult);
		if($res === false){
			$this->error = '数据转换为XML格式时出错';
			return false;
		}

		$res = strval($res);

		if($res < 0){
			if(array_key_exists($res, $this->errorArr)){
				$this->error = $this->errorArr[$res];
			}else{
				$this->error = '查询余额异常';
			}
			return false;
		}

		return $res;
	}


	public function setUrl($api = ''){
		$api = !empty($api) ? $api : $this->api;
		$this->url = $this->config['url'].'/'.$api;
	}

	public function setMobile($mobile){
		$this->mobile = $mobile;
	}
	public function getMobile(){
		return $this->mobile;
	}

	public function setContent($content){
		if(isset($this->config['signature']) && !empty($this->config['signature'])){
			$content .= $this->config['signature'];
		}
		$this->content = $content;
	}

	public function getContent(){
		return $this->content;
	}

	// 子类覆盖

	public function setParams(){}
	public function setHeaders(){}



}


