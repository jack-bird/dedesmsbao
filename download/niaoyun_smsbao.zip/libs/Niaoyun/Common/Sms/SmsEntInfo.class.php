<?php

namespace Niaoyun\Common\Sms;

use Org\Net\Curl;
use Niaoyun\Common\Sms\SmsBase;
use Think\Log;


class SmsEntInfo extends SmsBase {

	// entinfo
	// 发送短信处理：

	// 发送正常时返回的不是0或1，而是rrid
	// 如果请求参数有rrid，返回请求参数的rrid
	// 如果请求中rrid为空，则返回平台生成的rrid
	// 其它值为错误码
    public $error;

	public $errorArr = array(
		1 => '没有需要取得的数据',
		-2 => '账号/密码不正确',
		-4 => '余额不足',
		-5 => '数据格式错误',
		-6 => '参数有误',
		-7 => '权限受限',
		-8 => '流量控制错误',
		-9 => '扩展码权限错误',
		-10 => '内容过长',
		-11 => '内部数据库错误',
		-12 => '序列号状态错误',
		-13 => '没有提交增值内容',
		-14 => '服务器写文件失败',
		-15 => '文件内容base64编码错误',
		-16 => '返回报告库参数错误',
		-17 => '没有权限',
		-18 => '上次提交未返回，不能提交',
		-19 => '禁止同时使用多个接口地址',
		-20 => '相同手机号，相同内容重复提交',
		-22 => '禁止同时使用多个接口地址',
		-23 => '缓存无此序列号信息',
		-601 => '序列号为空，参数错误',
		-602 => '序列号格式错误，参数错误',
		-603 => '密码为空，参数错误',
		-604 => '手机号码为空，参数错误',
		-605 => '内容为空，参数错误',
		-606 => 'ext长度大于9，参数错误',
		-607 => '参数错误 扩展码非数字 ',
		-608 => '参数错误 定时时间非日期格式',
		-609 => 'rrid长度大于18,参数错误 ',
		-610 => '参数错误 rrid非数字',
		-611 => '参数错误 内容编码不符合规范',
		-623 => '手机个数与内容个数不匹配',
		-624 => '扩展个数与手机个数数',
		-625 => '定时时间个数与手机个数数不匹配',
		-626 => 'rrid个数与手机个数数不匹配',
	);
	//短信宝错误代码
	public $smsbao_errorArr=array(
		-1=>'参数不全',
		0=>'发送成功',
		30=>'密码错误',
		40=>'账号不存在',
		41=>'余额不足',
		42=>'帐号过期',
		43=>'IP地址限制',
		50=>'内容含有敏感词',
		51=>'手机号码不正确',
	);


	public function __construct($code){
		parent::__construct($code);
	}


	// public function send($mobile, $content, $id){
	public function send($mobile, $content, $id = null){ 
		$this->api = 'mt';
		$this->sendSetup($mobile, $content, $id);
		$s_config=$this->getConfig();
		$url=$s_config['url'];
		$param['u']=$s_config['apiId'];
		$param['p']=md5($s_config['apiKey']);
		$param['m']=$mobile;
		$param['c']=$s_config['signature'].$content;
		$result=file_get_contents($url.'?'.http_build_query($param));
		if($result!='0'){
			$this->error = $code . $smsbao_errorArr[$code];
            return false;
		}else{
			return true;
		}
		//return $this->processSendResult();
	}

	public function getBalance(){
		$this->api = 'balance';
		$this->setUrl();

		$this->params = array(
			'sn' => $this->_getSn(),
			'pwd' => $this->_getPassword(),
		);

		$this->post();
		return $this->processBalanceResult();
	}

	/**
	 * 检查内容（该短信平台未提供检查内容的接口）
	 */
	/*public function checkContent($content){

	}*/

	public function processSendResult(){
		$res = simplexml_load_string($this->rawResult);
		//$code = strval($res); // string
		// pf(__FILE__.': '.__LINE__);
		// pf($result);
		/*if(array_key_exists($code, $this->errorArr)){
			$this->status = 0;
			$this->error = $this->errorArr[$code];
			return false;
		}

		if (is_numeric($code) && $code < 0) {
            $this->error = $code . ' 未知错误';
            return false;
        }*/

		// $this->status = 1;
		$code=$res;
		if($code!='0'){
			$this->error = $code . $smsbao_errorArr[$code];
            return false;
		}else{
			return true;
		}
		
	}

	private function _getSn(){
		$sn = isset($this->config['apiId']) ? $this->config['apiId'] : '';
		$sn = $sn ? $sn : (isset($this->config['apiID']) ? $this->config['apiID'] : '');
		return $sn;
	}

	private function _getPassword(){
		return strtoupper(md5($this->_getSn().$this->config['apiKey']));
	}

	// content要gb2312编码！
	public function getContent(){
		return iconv('utf-8', 'gb2312', $this->content);
	}

	public function setParams(){
		// unset($config);
		$params = array(
			'sn' => $this->_getSn(),
			'pwd' => $this->_getPassword(),
			'mobile' => $this->getMobile(),
			'content' => $this->getContent(),
			'ext' => '',
			'stime' => '',
			'rrid' => $this->getMessageId(),
		);
		$this->params = $params;
	}

	public function setHeaders(){

	}

}


