<?php

/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/5/30
 * Time: 12:48
 */
class SmsBao
{
    const URL = 'http://api.smsbao.com/';

    public static function sendSms($userName, $password, $mobile='', $content='')
    {
        $password = md5($password);
        $content = urlencode($content);
        $sendUrl = self::URL . 'sms?u=' . $userName . '&p=' . $password . '&m=' . $mobile . '&c=' . $content;

        $ret = file_get_contents($sendUrl);

        if (0 != $ret) {
            return false;
        }

        return true;
    }
}