<?php
$lang = array(
	'mobile_auth_code'=>'您的手机认证码为：',
	'from'=>'来自',
	'apply_submit_fail_and_get_code'=>'申请提交成功，请验证来自手机短信验证码',
	'auth_audit_success'=>'手机认证成功',
	'code_error'=>'验证码错误',
	'autograph'=>'【指尖游】'

);