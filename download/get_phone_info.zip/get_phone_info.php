<?php
/**
 * Created by PhpStorm.
 * User: smsbao
 * Date: 2016/7/28
 * Time: 16:56
 */

// 用户接收用户的手机号码。
$phoneNume = $_GET['m'];

// 用户接收用户发送的内容。
$info = $_GET['c'];

// todo... 这里是您对的接收到数据的操作。比如：存入数据库等。

// 这里返回0表示您接收成功。如果不返回0，或者返回其他数据，则表示信息错误。
return 0;