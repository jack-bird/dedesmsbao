<?php
/**
 * Created by PhpStorm.
 * User: smsbao
 * Date: 2016/6/30
 * Time: 17:00
 */

function artical_submit($new, $old, $post) {

    global $wpdb;

    if ('pending' === $new) {
        $smsName = get_option('smsbao_name');
        $password = get_option('smsbao_password');
        $tmp = get_option('smsbao_audit_tmp');
        $phone = get_option('smsbao_phone');
        $title = $post->post_title;
        $userId = $post->post_author;
        $sql = "select user_nicename from {$wpdb->users} where ID='{$userId}'";
        $name =  $wpdb->get_var($sql);
        $sign = get_option('smsbao_sign');

        if (empty($tmp) || empty($phone) || empty($title) || empty($name) || empty($smsName) || empty($password)) {
            return;
        }

        $title = mb_substr($title, 0, 20);
        $password = md5($password);
        $content = str_replace('{user}', $name, $tmp);
        $content = '【' . $sign . '】' . str_replace('{title}', $title, $content);
        include 'send_sms.php';

        $res = send_sms($phone, $content, $smsName, $password);

        if (true !== $res) {
            file_put_contents('sms_log.txt', $res);
        }

    }
}

add_action('transition_post_status', 'artical_submit', 10, 3);