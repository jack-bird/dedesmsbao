<?php
/**
 * @Cscms 4.x open source management system
 * @copyright 2009-2015 chshcms.com. All rights reserved.
 * @Author:Cheng Jie
 * @Dtime:2014-08-21
 */

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * �ֻ�������
 */
class Smstel {

    function __construct ()
	{
		   $this->appid   = CS_Sms_ID;  //�̻�ID
		   $this->appkey  = CS_Sms_Key;  //�̻�KEY
           $this->curl    = 'http://api.smsbao.com/sms?';
	}

    //����
	function add($tel,$neir){
		   $param['u']=$this->appid;
		   $param['p']=md5($this->appkey);
		   $param['m']=trim($tel);
		   $param['c']='��'.CS_Sms_Name.'��'.$neir;
		   $param['c']=iconv('GBK', 'UTF-8', $param['c']);
		   //iconv('GB2312', 'UTF-8', $param['c']);
		   $url=$this->curl.(http_build_query($param));
		   //�绰�����Ƿ�Ϊ���
		   $send_num=0;
		   if(strstr($tel,",")){
			   $tel_array=explode(',',$tel);
			   foreach($tel_array as $key=>$val){
				   $msg=file_get_contents($url);
				   if($msg=='0'){
					   $send_num++;
				   }
			   }
		   }else{
			   $msg=file_get_contents($url);
			   if($msg=='0'){
				   $send_num++;
			   }
		   }
		   $send_num=$this->error($send_num);
		   return $send_num;
    }

    //����ע����֤��
	function seadd($tel){

		   $tel_time=$_SESSION['tel_time'];
           if($tel_time && $tel_time+60>time()){
		       return 'addok'; //����ʱ��û�й�60��
		   }
		   $code=random_string('nozero',4);
		   $_SESSION['tel_code']=$code;
		   $_SESSION['tel_time']=time();		   

		   $neir='��ӭע�ᣬ������֤����'.$code.'���뾡�������֤��(��Ǳ��˲������ɲ�������)';
		   $param['u']=$this->appid;
		   $param['p']=md5($this->appkey);
		   $param['m']=trim($tel);
		   $param['c']='��'.CS_Sms_Name.'��'.$neir;
		   $param['c']=iconv('GBK', 'UTF-8', $param['c']);
		   $url=$this->curl.(http_build_query($param));
		   $msg=file_get_contents($url);
		   $msg=$this->error($msg);
		   return $msg;
    }

    //��ѯ���
	function balance(){

		   //$get='rmb?u='.$this->appid;
		   //$get.='&p='.md5($this->appkey);
           $rmb=file_get_contents("http://www.smsbao.com/query?u=".$this->appid."&p=".md5($this->appkey));
		   $array=explode(',',$rmb);
		   return $array[1];
    }

    //��ѯ��¼
	function lists($len=12,$p=1){

		   $get='lists?uid='.$this->appid;
		   $get.='&key='.$this->appkey;
		   $get.='&len='.$len;
		   $get.='&p='.$p;
           $url=$this->curl.$get;
		   $str=htmlall($url);
		   return $str;
    }

    //������ʾ
    function error($msg){
		    if(empty($msg)){
                 return L('curl_err');
			}
            return $msg;
	}
}


