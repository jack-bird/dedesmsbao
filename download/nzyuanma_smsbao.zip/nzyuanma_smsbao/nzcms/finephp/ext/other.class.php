<?php
class other{
    public static function hidecard($type,$str) {
		if($type==1){ //手机号
			$res = substr($str,0,4)."****".substr($str,8,3);
		}elseif($type==2){//用户名
			$res = utf8::substr($str,0,2).str_repeat("*",strlen($str)-2);
		}elseif($type==3){//IP
			$res = substr($str, 0, strrpos($str, '.')).'.*';
		}
        return $res;
    }
	public static function rand_string($len = 6, $type = '1', $addChars = '') {
		$str = '';
		switch ($type) {
			case 0:
				$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz' . $addChars;
				break;

			case 1:
				$chars = str_repeat('0123456789', 3);
				break;

			case 2:
				$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' . $addChars;
				break;

			case 3:
				$chars = 'abcdefghijklmnopqrstuvwxyz' . $addChars;
				break;

			default:
				// 默认去掉了容易混淆的字符oOLl和数字01，要添加请使用addChars参数
				$chars = 'ABCDEFGHIJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789' . $addChars;
				break;
		}
		if ($len > 10) { //位数过长重复字符串一定次数
			$chars = $type == 1 ? str_repeat($chars, $len) : str_repeat($chars, 5);
		}
		$chars = str_shuffle($chars);
		$str = substr($chars, 0, $len);
		return $str;
	}
	public static function auto_charset($fContents, $from='gbk', $to='utf-8') {
		$from = strtoupper($from) == 'UTF8' ? 'utf-8' : $from;
		$to = strtoupper($to) == 'UTF8' ? 'utf-8' : $to;
		if ( ($to=='utf-8' && is_utf8($fContents)) || strtoupper($from) === strtoupper($to) || empty($fContents) || (is_scalar($fContents) && !is_string($fContents))) {
			return $fContents;
		}
		if (is_string($fContents)) {
			if (function_exists('mb_convert_encoding')) {
				return mb_convert_encoding($fContents, $to, $from);
			} elseif (function_exists('iconv')) {
				return iconv($from, $to, $fContents);
			} else {
				return $fContents;
			}
		} elseif (is_array($fContents)) {
			foreach ($fContents as $key => $val) {
				$_key = auto_charset($key, $from, $to);
				$fContents[$_key] = auto_charset($val, $from, $to);
				if ($key != $_key)
					unset($fContents[$key]);
			}
			return $fContents;
		}else{
			return $fContents;
		}
	}
    public static function send_sms($config,$mob, $content){
		switch ($config['type']){ // type=1 短信宝
			case 1:
				$uid = $config['sms_user']; 	//账号
				$pwd = $config['sms_password']; //密码
				$content = urlencode($content); //短信内容
				
				$url	= "http://api.smsbao.com/sms?u=" . $uid . "&p=" . md5($pwd) . "&m=" . $mob . "&c=" . $content;
				$data 	= fetch_url($url,10);
				$res 	= explode("/", $data);
				if($res[0] == "000"){
					return true;
				}else{
					return false;
				}
				break;
			case 2:
				return false;
				break;
			case 3:
				return false;
				break;
			default:
				return false;
		}
    }
}
?>