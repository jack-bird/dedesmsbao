<?php 
return array (
  'sms_url' => 'http://api.smsbao.com/sms',
  'sms_user' => 'smsbao',
  'sms_key' => 'key6523',
  'sms_price' => '8',
  'sms_sign' => 'pigcms',
  'sms_mp' => '13888888888',
  'reg_mp_verify' => '0',
);