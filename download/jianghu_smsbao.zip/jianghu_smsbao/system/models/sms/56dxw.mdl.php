<?php
/**
 * Copy Right Abc576.com
 * Each engineer has a duty to keep the code elegant
 * Author @shzhrui<Anhuike@gmail.com>
 * $Id: 56dxw.mdl.php 3350 2014-02-18 01:33:22Z youyi $
 */

Import::I('sms');
class Mdl_Sms_56dxw implements Sms_Interface
{   
    protected $gateway = 'http://api.smsbao.com/sms?';
    protected $_cfg = array();

    public $lastmsg = '';
	public $lastcode = 1;

    public function __construct($system)
    {
    	$this->_cfg = $system->config->get('sms');
    }
    
    public function send($mobile, $content)
    {
    	

        $url = $this->gateway.'u='.$this->_cfg['uname'].'&p='.md5($this->_cfg['passwd']).'&m='.$mobile.'&c='.$content;

        $ret = file_get_contents($url);

    	
    		if($ret == 0){

    			return true;
    		}else{
                switch($ret){
				   case 30:$error='密码错误';break;
				   case 40:$error='账号不存在';break;
				   case 41:$error='余额不足';break;
				   case 42:$error='账号过期';break;
				   case 43:$error='IP地址限制';break;
				   case 50:$error='内容含有敏感词';break;
				   case 51:$error='手机号码不正确';break;
				}
				$this->lastcode = $ret;
				$this->lastmsg = $error;
    		}
    	
    }
}