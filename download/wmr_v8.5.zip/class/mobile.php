<?php 

/**
 * @class mobile
 * @brief 发送短信类
 * @Author smsbao
 */
class mobile
{
	   const sendSmsUrl = "http://api.smsbao.com/sms";
	   private $u; //短信宝用户名，请直接到短信宝官网www.smsbao.com注册即可
	   private $p;//短信宝账号密码 
	   private $sign;//短信的签名 
	 
	  function __construct(){ 	 
	  	header("Content-Type: text/html; charset=UTF-8");
	  	$this->u =  Mysite::$app->config['sms86ac'];
	  	$this->p =  Mysite::$app->config['sms86pd'];	
   }
   
  
   
	
   
	 /*
	   sendsms()  发送短信  
	   param 说明
	      $phonenum 电话号码数组 array('159xxxxxxxx','159xxxxxxxx')
	      $content  发送内容
	  */
	 function sendsms($phonenum,$content){ 
	 	$param['u'] = $this->u;
        $param['p'] = md5($this->p);
        $param['m'] = $phonenum;
        $param['c'] = $content;
        $ret = self::http(self::sendSmsUrl, $param);
        $return_data = $ret == 0 ?'ok' : self::getResult($ret);
        return $return_data; 
	 } 
	 
	 /**
     * 发送http请求
     * @access protected
     * @param string $url  请求地址
     * @param string $param  get方式请求内容，数组形式，post方式时无效
     * * @param string $data  post请求方式时的内容，get方式时无效
     * @param string $method  请求方式，默认get
     */
    protected static function http($url, $param, $data = '', $method = 'GET'){
        $opts = array(
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        );
    
        /* 根据请求类型设置特定参数 */
        $opts[CURLOPT_URL] = $url . '?' . http_build_query($param);
    
        if(strtoupper($method) == 'POST'){
            $opts[CURLOPT_POST] = 1;
            $opts[CURLOPT_POSTFIELDS] = $data;
    
            if(is_string($data)){ //发送JSON数据
                $opts[CURLOPT_HTTPHEADER] = array(
                    'Content-Type: application/json; charset=utf-8',
                    'Content-Length: ' . strlen($data),
                );
            }
        }
    
        /* 初始化并执行curl请求 */
        $ch = curl_init();
        curl_setopt_array($ch, $opts);
        $data  = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
    
        //发生错误，抛出异常
        if($error) throw new \Exception('请求发生错误：' . $error);
    
        return  $data;
    }
    private function getResult($key){
        $rst['30'] = '密码错误';
        $rst['40'] = '账号不存在';
        $rst['41'] = '余额不足';
        $rst['42'] = '帐号过期';
        $rst['43'] = 'IP地址限制';
        $rst['50'] = '内容含有敏感词';
        $rst['51'] = '手机号码不正确';
        return $rst[$key];
    }

}
?>