<?php
/**
 * SmsBao实现类
 * @category   dedeCMS V5.7
 * @subpackage  Sms
 * @author    linf
 */
    session_start();
    require_once(dirname(__FILE__)."/config.php");
    //require_once(DEDEMEMBER."/templets/reg-new2.htm");
	require_once(DEDEMEMBER . '/lib_sms.php');
	//require_once(DEDEMEMBER . '/sms.php');
	// 短信内容
	//$verifycode = getverifycode();
	$vacode=rand('111111','999999');
	PutCookie('mobile_vcode', $vacode, 60*5, '/');
	//setcookie("mobile_vcode",$vacode, 60*5);
    $message="您的验证码是：".$vacode."。请不要把验证码泄露给其他人。";
	 $row = $dsql->GetOne("SELECT * FROM `#@__sysconfig` WHERE varname='cfg_smsbao_name' ");
	 $row_pwd = $dsql->GetOne("SELECT * FROM `#@__sysconfig` WHERE varname='cfg_smsbao_password' ");
	 $row_sign = $dsql->GetOne("SELECT * FROM `#@__sysconfig` WHERE varname='cfg_smsbao_sign' ");	
	$infos=$row['value'].','.$row_pwd['value'].','.$row_sign['value'].','.$_POST['mobile_phone'];
	$result = sendsms($infos, $message);
	if($result=='0'){
		echo '验证码已发送，请注意查收';
	}else{
		echo '验证码发送失败，请重试，错误代码：'.$result;
	}
?>