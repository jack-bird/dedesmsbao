<?php
	if (!defined('in_mx')) {exit('Access Denied');}
    date_default_timezone_set('Asia/Shanghai'); 
	
	$sms_mod = array();
	$sms_mod['code']    = "smsbao"; //代码
	$sms_mod['name']    = '短信宝';//名称
	$sms_mod['config']  =  json_encode(array('appkey'=>'','secretKey'=>'','reg'=>'','login'=>'','updatepwd'=>'','setpaypwd'=>'','changemobile'=>''));//配置信息
	$sms_param=array(
		array('name'=>'smsconfig_appkey','value'=>'appkey','type'=>'text','desc'=>"短信宝用户名，还没有短信宝账户？点击马上<a href='http://www.smsbao.com' target='_blank'>免费注册</a>"),
		array('name'=>'smsconfig_secretKey','value'=>'secretKey','type'=>'text','desc'=>'短信宝密码'),
		array('name'=>'smsconfig_reg','value'=>'注册模板','type'=>'text','desc'=>''),
		array('name'=>'smsconfig_login','value'=>'登录模板','type'=>'text','desc'=>''),
		array('name'=>'smsconfig_updatepwd','value'=>'修改密码模板','type'=>'text','desc'=>''),
		array('name'=>'smsconfig_setpaypwd','value'=>'设置支付密码模板','type'=>'text','desc'=>''),
		array('name'=>'smsconfig_changemobile','value'=>'更改手机号码模板','type'=>'text','desc'=>''),
		array('name'=>'smsconfig_order','value'=>'订单提醒模板','type'=>'text','desc'=>'有新订单时，短信提醒'),
	  ); 

	function sendsms($recNum, $appkey,$secretKey,$signName='',$param='',$tplcode='',$extend='',$sms_type='code')
	{
		$pa['u'] = $appkey;
        $pa['p'] = md5($secretKey);
        $pa['m'] = $recNum;
		$tpl=$tplcode;
		$param=json_decode($param);
		foreach($param as $key=>$val){
			if(strpos($tpl,$key)){
				$tpl=str_replace('${'.$key.'}',$val,$tpl);
			}
		}
        $pa['c'] = "【".$signName."】".$tpl;
        $ret = http("http://api.smsbao.com/sms", $pa);
		$data=array('err'=>'');
		if($ret!='0'){
			return $data['err']=getResult($ret);
		}
        
	}
	
	 /**
     * 发送http请求
     * @access protected
     * @param string $url  请求地址
     * @param string $param  get方式请求内容，数组形式，post方式时无效
     * * @param string $data  post请求方式时的内容，get方式时无效
     * @param string $method  请求方式，默认get
     */
   function http($url, $param, $data = '', $method = 'GET'){
        $opts = array(
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        );
    
        /* 根据请求类型设置特定参数 */
        $opts[CURLOPT_URL] = $url . '?' . http_build_query($param);
    
        if(strtoupper($method) == 'POST'){
            $opts[CURLOPT_POST] = 1;
            $opts[CURLOPT_POSTFIELDS] = $data;
    
            if(is_string($data)){ //发送JSON数据
                $opts[CURLOPT_HTTPHEADER] = array(
                    'Content-Type: application/json; charset=utf-8',
                    'Content-Length: ' . strlen($data),
                );
            }
        }
    
        /* 初始化并执行curl请求 */
        $ch = curl_init();
        curl_setopt_array($ch, $opts);
        $data  = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
    
        //发生错误，抛出异常
        if($error) throw new \Exception('请求发生错误：' . $error);
    
        return  $data;
    }
    function getResult($key){
        $rst['30'] = '密码错误';
        $rst['40'] = '账号不存在';
        $rst['41'] = '余额不足';
        $rst['42'] = '帐号过期';
        $rst['43'] = 'IP地址限制';
        $rst['50'] = '内容含有敏感词';
        $rst['51'] = '手机号码不正确';
        return $rst[$key];
    }

?>