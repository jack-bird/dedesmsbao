<?php
if (!defined('in_mx')) {exit('Access Denied');}

$db = dbc(); 
global $db;
$res=$db->insert('sms_config',array('code'=>'smsbao', 'name'=>'短信宝','signname'=>'云EC','config'=>'{"appkey":"","secretKey":"","reg":"${product},\u60a8\u7684\u9a8c\u8bc1\u7801\u4e3a\uff1a${code}\u6253\u6b7b\u4e5f\u4e0d\u80fd\u544a\u8bc9\u522b\u4eba\u54e6","login":"${product},\u60a8\u7684\u9a8c\u8bc1\u7801\u4e3a\uff1a${code}\u6253\u6b7b\u4e5f\u4e0d\u80fd\u544a\u8bc9\u522b\u4eba\u54e6","updatepwd":"${product},\u60a8\u7684\u9a8c\u8bc1\u7801\u4e3a\uff1a${code}\u6253\u6b7b\u4e5f\u4e0d\u80fd\u544a\u8bc9\u522b\u4eba\u54e6","setpaypwd":"${product},\u60a8\u7684\u9a8c\u8bc1\u7801\u4e3a\uff1a${code}\u6253\u6b7b\u4e5f\u4e0d\u80fd\u544a\u8bc9\u522b\u4eba\u54e6","changemobile":"${product},\u60a8\u7684\u9a8c\u8bc1\u7801\u4e3a\uff1a${code}\u6253\u6b7b\u4e5f\u4e0d\u80fd\u544a\u8bc9\u522b\u4eba\u54e6","order":"\u606d\u559c\u4f60\u4e0b\u5355\u6210\u529f\uff0c\u8ba2\u5355\u53f7\u4e3a\uff1a${order_sn},\u795d\u4f60\u8d2d\u7269\u6109\u5feb\uff01"}','status'=>1));
if($res){
	echo '短信宝插件安装成功，请删除inc/module/smsbao_install.php文件';
}else{
	echo '安装失败，请咨询短信宝客服';
}
exit();
?>