<?php
if (!defined('in_mx')) {exit('Access Denied');}
 
checkAuth($login_id, 'message');//权限检测 
 
$code = $code=='' ?'smsbao':$code;
$sp_file = plugin."sms/".$code.'/'.$code.'.php';
if(file_exists($sp_file)==false){message("获取不到短信文件 ".$code.'.php');}
require($sp_file);
 
$row = $db->fetch('sms_config', '*',  array('code' => $code));
$sms_config = json_decode($row['config'], true);
$cbk_status[$row['status']] =' checked="checked"';

foreach ($sms_param as $k => $v) {
	$sms_param[$k]['key']= str_replace('smsconfig_', '', $v['name']);
}


	 
?>