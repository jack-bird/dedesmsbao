/**
 * Created by king on 16/4/26.
 */
// ajax防止重复提交标记
var flg = true;
var isOpen = false;
var openTime = 3;

var countdown = 5;
var res = null;
var cres = null;

// 页面刷新时客服对话框展示3秒
function showCustomer() {

    if (0 == openTime && true == isOpen) {

        if ($("#aFloatTools_Hide").length > 0) {
            $("#aFloatTools_Hide").click();
        }

        isOpen = false;
        clearTimeout(cres);
        return;
    } else {
        openTime--;
        isOpen = true;
    }

    cres = setTimeout(function() {
        showCustomer()
    },1000)
}

//// 切换验证码
//function editCode(that) {
//    that.src = "http://www.smsbao.com/special/plugin/verify_code.php?" + Math.random();
//}

//// 判断浏览器是否支持placeholder属性
//function placeholderSupport() {
//    return 'placeholder' in document.createElement('input');
//}

//function settime(val) {
//    if (countdown == 0) {
//        val.removeAttribute("disabled");
//        $(val).text("发送测试");
//        clearTimeout(res);
//        return;
//    } else {
//        val.setAttribute("disabled", true);
//        $(val).text("重新发送(" + countdown + ")");
//        countdown--;
//    }
//
//    res = setTimeout(function() {
//        settime(val)
//    },1000)
//}

// ajax提交参数到后台
//function getVal(val) {
//    flg = false; // 防止重复提交
//
//    $.ajax({
//        "url" : "http://www.smsbao.com/special/ajax/test_ajax.php",
//        "data" : val,
//        "dataType" : "json",
//        "type" : "post",
//        "success" : function(obj) {
//            //conslog.log(obj);
//            if (true == obj.flg && null == obj.error) {
//                countdown = 60;
//                settime($("#sub")[0]);
//                editCode($("#code")[0]);
//                $(".error").html("发送成功。感觉不错？<a href='/reg' class='reg'>立即注册</a>, 即送体验短信。").css({"color":"green", "text-align":"center"});
//            } else {
//                $(".error").text("发送失败。原因：" + obj.error).css({"color":"red", "text-align":"center"});
//            }
//
//            flg = true;
//        }
//    });
//}

$(function() {

    //// placeholder标签兼容方案
    //if(!placeholderSupport()){   // 判断浏览器是否支持 placeholder
    //    $("[placeholder]").css("color", "#989898");
    //    $('[placeholder]').focus(function() {
    //        var input = $(this);
    //        if (input.val() == input.attr('placeholder')) {
    //            input.val('');
    //            input.removeClass('placeholder');
    //        }
    //    }).blur(function() {
    //        var input = $(this);
    //        if (input.val() == '' || input.val() == input.attr('placeholder')) {
    //            input.addClass('placeholder');
    //            input.val(input.attr('placeholder'));
    //        }
    //    }).blur();
    //}

    // 主导航的子栏目菜单下滑，以纵向列表显示
    if ($(".show_column").length > 0) {
        $(".show_column").subColumnShow({
            "pullDownBgColor":"#fff",
            "pullDownBorder":"1px solid #eee",
            "showSpeed":200
        });
    }

    // 全屏带背景轮播，自动适应屏幕
    //if ($("#banner").length > 0) {
        $("#center_main3").aroundAutoSwitchAllScreen({
            "iconClass":"allScreen-icon", //图标的节点
            "speed":3800, //动画播放速度
            "mainClass":"autoSwitchAllScreen-main" //动画节点，一般是ul

        });
    //}

    // 案例提示框
    //if ($(".show-pop").length > 0) {
    //    $(".show-pop").webuiPopover(
    //        {
    //            "placement":"top",
    //            "width":250,
    //            "height":50,
    //            "trigger":"hover",
    //            "delay":"300"
    //        }
    //    );
    //}

    // 五大优势切换
    //if ($("#advantage").length > 0) {
    //    $(".shiftSwitch-main").shiftSwitch({
    //        "heightAdd":0,
    //        "moveType":"downToUp",
    //        "speed":300,
    //        "subNode":"div"
    //    });
    //}

    // 验证码点击切换
    //if ($("#code").length > 0) {
    //    $("#code").on("click", function() {
    //        editCode(this);
    //    });
    //}

    // 提交免费短信测试
    //if ($("#test_form").length > 0) {
    //    var val = null;
    //
    //    $("#test_form").on("submit", function() {
    //        if (true === flg) {
    //            val = $(this).serialize();
    //            getVal(val);
    //        }
    //
    //        return false;
    //    });
    //}

    // 网页加载时，让右面在线客服展开一下
    if ($("#floatTools").length > 0) {
        if (false == isOpen) {
            $("#aFloatTools_Show").click();

            setTimeout(function() {
                showCustomer();
            },1000);
        }
    }

    //

});
