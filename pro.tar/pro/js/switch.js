/**
 * Created by king on 16/4/26.
 */
(function($) {
    $.fn.shiftSwitch = function(o) {

        var opts = $.extend({}, $.fn.shiftSwitch.defaults, o);
        var ele = this;
        var type = opts.moveType.toLowerCase();
        var speed = opts.speed;
        var move = {};
        var moveType = "";
        var width = [];
        var height = [];
        var i = 0;
        var that = null;
        var index = 0;
        var range = 0;
        var isAutoMove = opts.offsetPos;
        var offWidth = 0;

        $.C_getIndex = function(eleLists, currentNode) {
            eleLists = $(eleLists);
            currentNode = $(currentNode);

            var index = -1;

            if (eleLists.length < 1) {
                return null;
            }

            for (var i=0; i<eleLists.length; i++) {
                if (currentNode[0] == eleLists[i]) {
                    index = i;
                }
            }

            return index;
        };

        ele.each(function() {
            that = $(this);
            width[i] = that.find(opts.subNode).width();
            height[i] = that.find(opts.subNode).height();
            i++;
        });

        if ("auto" !== isAutoMove) {
            type = "righttoleft";
        }


        switch (type) {
            case "downtoup":
                moveType = "margin-top";
                range = "height";
                break;
            case "righttoleft":
                moveType = "margin-left";
                range = "width";
                break;
            default :
                return false;
                break;

        }

        ele.on("mouseenter", function() {
            index = $.C_getIndex(ele, this);
            if ("auto" === isAutoMove) {
                move[moveType] = "height" === range
                    ? height[index] * -1
                    : width[index] * -1;
            } else {
                offWidth = $(this).find(opts.subNode).eq(0).css("padding-left");
                offWidth = parseInt(offWidth);
                move[moveType] = offWidth * -1;
            }

            $(this).find(opts.subNode).eq(0).animate(move, speed);
        });

        ele.on("mouseleave", function() {
            move[moveType] = 0;
            $(this).find(opts.subNode).eq(0).stop(true, false).animate(move, speed);
        });

        return $(this);

    };

    //默认样式
    $.fn.shiftSwitch.defaults = {
        "moveType":"downToUp",
        "speed":300,
        "offsetPos":"auto",
        "subNode":"img"
    };

})(jQuery);
