<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/8/5
 * Time: 13:13
 */

// 生成的验证码，存入到数据库中。
// 用户多次提交后，获取的验证码应该是一样的。
// 验证用户提交时间是否在一分钟之内。
// 验证用户当天提交次数。
// 验证用户提交的ip地址是否超过当天限制。a
// 提交后用户，把用验证码先保存一份临时验证码。
// 用户收到验证码后，再输入验证码,然后后端比对。
// 判断一下然后
session_start();
$code = strtolower($_SESSION['code']);
$userCode = strtolower($_POST['vcode']);

echo $userCode; exit;