<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/8/5
 * Time: 13:20
 */
session_start();
require('tool/CheckTool.php');
require('tool/Helpers.php');

$diff = '';

if (isset($_SESSION['send_time']) && is_int($_SESSION['send_time'])) {
    $currentTime = time();
    $diff = $currentTime - $_SESSION['send_time'];
    $diff = $diff < 60 ? 60 - $diff : '';
}

if (!empty($_POST['is_send'])) {
    $data = Helpers::removeSpaces($_POST);
    $res = CheckTool::exec($data);

    if (!is_array($res) && true === $res) {
        $_SESSION['sms_code'] = null;
        $_SESSION['send_phone'] = null;
        unset($_SESSION['sms_code']);
        unset($_SESSION['send_phone']);
        header("Location:login.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        * {margin:0; padding:0;}
        h1 {margin:30px 0 25px 0;}
        .form-input {margin-bottom:10px;}
        .form-input input {width:200px; height:25px;}
        .form-input button {width:60px; height:25px;}
        #main {width:500px; margin:0 auto;}
        #vcode {width:80px;}

        #phone_code {width:80px;}
        .code_label {position:relative;}
        .code_label img {position:absolute; top:-5px; left:185px; cursor: pointer;}
        .code_label button {width:90px; cursor: pointer;}
    </style>
    <script src="js/jquery.js"></script>
    <script>
        var time = 0;
        var res = null;
        var sendNode = null;
        var diffTime = "<?php echo $diff; ?>";

        function sendTime() {
            clearTimeout(res);
            time--;

            if (time < 0) {
                time = "获取验证码";
                sendNode.text(time);
                clearTimeout(res);
                time = 0;
                return;
            }

            sendNode.text("剩余" + time + "秒");
            res = setTimeout("sendTime()", 1000);
        }

        $(function(){
            sendNode = $("#get_code");
            var flg = true;

            if ("" != diffTime) {
                time = parseInt(diffTime);
                sendTime();
            }

            sendNode.on("click", function() {

                if (0 == time) {
                    var phoneNum = $("input[name='phone']").val();
                    var code = $("input[name='vcode']").val();
                    var data = {"code" : code, "phone" : phoneNum};
                    var err = "";

                    if (flg == true) {
                        flg = false;

                        $.ajax({
                            "url" : "./tool/sendCode.php",
                            "type" : "post",
                            "data" : data,
                            "dataType" : "json",
                            "success" : function (msg) {
                                $(".errmsg").text("");

                                if (-1 == msg.flg) {
                                    err = msg.err;

                                    if ("code" == msg.type) {
                                        $("#code_err").text(err);
                                    } else if ("phone" == msg.type) {
                                        $("#phone_err").text(err);
                                    } else {
                                        alert("短信发送失败，原因：" + err);
                                    }
                                } else {
                                    time = 60;
                                    sendTime();
                                    alert("发送验证码成功！");
                                }

                                $("#code_img").click();
                                flg = true;
                            }
                        });
                    }

                    return false;
                }

            });


        });
    </script>
</head>
<body>
<div id="main">
    <h1>用户注册</h1>
    <form method="post" action="register.php">
        <div class="form-input">
            <label>
                手机号码&emsp;
                <input type="text" name="phone" value="<?php echo isset($_POST['phone']) ? $_POST['phone'] : ''; ?>"/>
                <p id="phone_err" class="errmsg" style="margin:5px 0 0 88px; color:red;"><?php echo isset($res['phone']) ? $res['phone'] : ''; ?></p>
            </label>
        </div>
        <div class="form-input">
            <label>
                密&emsp;&emsp;码&emsp;
                <input type="password" name="password" value="<?php echo isset($_POST['password']) ? $_POST['password'] : ''; ?>"/>
                <p id="phone_err" class="errmsg" style="margin:5px 0 0 88px; color:red;"><?php echo isset($res['password']) ? $res['password'] : ''; ?></p>
            </label>
        </div>
        <div class="form-input">
            <label>
                确认密码&emsp;
                <input type="password" name="repassword" value=""/>
            </label>
        </div>

        <div class="form-input">
            <label class="code_label">
                验&ensp;证&ensp;码&emsp;
                <input id="vcode" type="text" name="vcode" value=""/>
                <img id="code_img" src="./tool/show_code.php" onclick="this.src='./tool/show_code.php?'+Math.random()" />
                <p id="code_err" class="errmsg" style="margin:5px 0 0 88px; color:red;"></p>
            </label>
        </div>
        <div class="form-input">
            <label class="code_label">
                手机验证码
                <input id="phone_code" type="text" name="code" value="<?php echo isset($_POST['code']) ? $_POST['code'] : ''; ?>"/>
                <button type="button" id="get_code">获取验证码</button>
                <p id="phone_err" class="errmsg" style="margin:5px 0 0 88px; color:red;"><?php echo isset($res['code']) ? $res['code'] : ''; ?></p>
            </label>
        </div>
        <input type="hidden" name="is_send" value="1"/>
        <div class="form-input">
            <label>
                <button type="submit">提 交</button>
            </label>
        </div>
    </form>
</div>

</body>
</html>
