<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/8/11
 * Time: 17:04
 */
session_start();
require('./Code.php');
$code = new Code();
$code->make();