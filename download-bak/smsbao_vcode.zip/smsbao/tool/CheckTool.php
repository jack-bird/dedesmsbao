<?php

/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/8/12
 * Time: 9:25
 */
class CheckTool
{
    private static $errArr = array(
        0 => '用户名不得为空',
        1 => '密码不能为空',
        2 => '2次输入的密码不一致',
        3 => '手机验证码不正确',
        4 => '验证码不得为空',
        5 => '验证码填写不正确',
        6 => '手机号码格式不正确',
        7 => '手机号码必须填写',
        8 => '请先获取短信验证码',
        9 => '短信验证码不正确',
        10 => '密码不得少于6位数',
        11 => '验证的手机号码和当前的手机号码不一致'
    );

    public static function exec($data)
    {
        $errType['phone'] = self::checkPhone($data['phone']);
        $errType['password'] = self::checkPassword($data['password'], $data['repassword']);
        $errType['code'] = self::checkSmsCode($data['code']);

        return self::checkErr($errType);
    }

    public static function checkErr($errorData)
    {
        $cnt = count($errorData);
        $postOk = 0;

        foreach ($errorData as $key => $item) {
            if (true === $item) {
                $errorData[$key] = '';
                ++$postOk;
            }
        }

        return $cnt == $postOk ? true : $errorData;
    }


    public static function checkSmsCode($code)
    {
        if (!isset($_SESSION['sms_code']) || empty($_SESSION['sms_code'])) {
            return self::$errArr[8];
        }

        if (0 !== strcmp($_SESSION['sms_code'], $code)) {
            return self::$errArr[9];
        }

        return true;
    }

    public static function checkPassword($password, $repassword)
    {
        if (empty($password)) {
            return self::$errArr[1];
        }

        if (!is_string($password) || strlen($password) < 6) {
            return self::$errArr[10];
        }

        if (0 !== strcmp($password, $repassword)) {
            return self::$errArr[2];
        }

        return true;
    }

    public static function checkUpperLimit($upperLimit)
    {
        if (empty($codeTime)) {
            return true;
        }

        if ($codeTime < 0 || !is_int($codeTime)) {
            return self::$errArr[9];
        }

        return true;
    }


    public static function checkName($name)
    {
        if (empty($name)) {
            return self::$errArr[0];
        }

        return true;
    }


    /**
     * 验证码
     *
     * @param $code
     * @return bool|mixed
     */
    public static function checkCode($code)
    {
        if (empty($code)) {
            return self::$errArr[4];
        }

        session_start();
        $code = strtolower($code);
        $sessionCode = strtolower($_SESSION['code']);

        if (0 !== strcmp($code, $sessionCode)) {
            return self::$errArr[5];
        }

        return true;
    }

    /**
     * 手机验证
     *
     * @param $phone
     * @return bool|mixed
     */
    public static function checkPhone($phone)
    {
        if (empty($phone)) {
            return self::$errArr[7];
        }
        
        $isOk = preg_match('/^13[0-9]{1}[0-9]{8}$|15[0189]{1}[0-9]{8}$|189[0-9]{8}$/', $phone);

        if (!$isOk) {
            return self::$errArr[6];
        }

        if (isset($_SESSION['send_phone'])) {
            if (0 !== strcmp($_SESSION['send_phone'], $phone)) {
                return self::$errArr[11];
            }
        }

        return true;
    }
}