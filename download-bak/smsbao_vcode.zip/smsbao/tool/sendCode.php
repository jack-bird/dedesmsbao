<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/8/12
 * Time: 14:26
 */

require 'CheckTool.php';

$statusStr = array(
    "0" => "短信发送成功",
    "-1" => "参数不全",
    "-2" => "服务器空间不支持,请确认支持curl或者fsocket，联系您的空间商解决或者更换空间！",
    "30" => "密码错误",
    "40" => "账号不存在",
    "41" => "余额不足",
    "42" => "帐户已过期",
    "43" => "IP地址限制",
    "50" => "内容含有敏感词"
);

$res = array();
$postCode = trim($_POST['code']);
$postPhone = trim($_POST['phone']);

$isOk = CheckTool::checkCode($postCode);

if (true !== $isOk) {
    echo responseErr($isOk, 'code');
    exit();
}

$isOk = CheckTool::checkPhone($postPhone);

if (true !== $isOk) {
    echo responseErr($isOk, 'phone');
    exit();
}

$isOk = sendSms($postPhone);

if (0 != $isOk) {
    echo responseErr($statusStr[$isOk], 'send');
    exit();
}

$res['flg'] = 1;
$_SESSION['send_time'] = time();
$_SESSION['send_phone'] = $postPhone;
echo json_encode($res);

function sendSms($phoneNum) {
    $data = include('../config/config.php');

    if (empty($data)) {
        return "40";
    }

    $url = 'http://www.smsbao.com/sms?';
    $userName = $data['smsbao_name']; //数据库获取用户名
    $password = md5($data['smsbao_password']); //数据库获取密码
    $phone = $phoneNum;
    $code = rand(100000, 999999);
    $content = '【短信宝】你的短信验证码为'.$code.'，请及时查收，如非本人操作，请忽略。';
    $url .= 'u=' . $userName . '&p=' . $password . '&m=' . $phone . '&c=' . urlencode($content);
    $_SESSION['sms_code'] = $code;

    return file_get_contents($url);
}

function responseErr($msg, $type)
{
    $res = array();
    $res['flg'] = -1;
    $res['err'] = $msg;
    $res['type'] = $type;

    return json_encode($res);
}
