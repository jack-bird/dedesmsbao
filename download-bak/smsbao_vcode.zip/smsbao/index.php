<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>短信验证码案例</title>
    <style>
        * {padding:0; margin:0;}
        #main {width:500px; margin: 0 auto; text-align:center;}
        h1 {margin:60px 0 25px 0;}
        h3 {height:50px; line-height:50px;}
    </style>
</head>
<body>
    <div id="main">
        <h1>短信宝短信验证码案例</h1>
        <h3>
            <a href="register.php">进入模拟手机注册页面</a>
        </h3>
    </div>
</body>
</html>