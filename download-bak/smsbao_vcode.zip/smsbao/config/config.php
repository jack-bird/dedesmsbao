<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/8/12
 * Time: 14:37
 */
return array(
    'smsbao_name' => 'smsbao_user', // 您的短信宝账号
    'smsbao_password' => 'smsbao_password', // 您的短信宝密码
);