<?php
require('tool/CheckTool.php');
require('tool/DBTool.php');
require('tool/Helpers.php');

$arr = array();

if (!empty($_POST['is_send'])) {
    $data = Helpers::removeSpaces($_POST);
    $bool = CheckTool::checkName($data['name']);

    if (true !== $bool) {
        $arr['name'] = $bool;
    }

    $bool = CheckTool::checkPassword($data['name']);

    if (true !== $bool) {
        $arr['password'] = $bool;
    }

    $data['code_time'] += 0;
    $bool = CheckTool::checkCodeTime($data['code_time']);

    if (true !== $bool) {
        $arr['code_time'] = $bool;
    }

    $data['day_cnt'] += 0;
    $bool = CheckTool::checkUpperLimit($data['day_cnt']);

    if (true !== $bool) {
        $arr['day_cnt'] = $bool;
    }

    if (empty($arr)) {
        $db = DBTool::getInstance();
        $sql = 'SELECT id FROM smsbao_config';
        $id = $db->getOne($sql);
        // 如果已经有记录了，就update，否则就insert
        if ($id) {
            //$db->update(, , , )
        } else {

        }
    }
    //Helpers::dd($bool);
}

require('tpl/smsbao.html');