<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>登入页面</title>

</head>
<body>
    <p style="text-align: center; margin-top:30px; font-size:25px;">恭喜你！登入成功！ <a style="color:blue;" href="register.php">返回</a>注册界面。</p>
</body>
</html>