<?php
//短信宝配置信息开始
$_LANG['cfg_name']['smsbao'] = '短信宝设置';

$_LANG['cfg_name']['smsbao_gateway'] = '短信通道接口';
$_LANG['cfg_desc']['smsbao_gateway'] = '以下短信功能所用发送短信的通道接口';
$_LANG['cfg_range']['smsbao_gateway'][1] = '短信宝服务平台';


$_LANG['cfg_name']['smsbao_user_name'] = '短信宝服务平台帐号';
$_LANG['cfg_desc']['smsbao_user_name'] = '请填写<a href="http://www.smsbao.com/" target="_blank"><font color="red"><b>短信宝服务平台</b></font></a>注册的帐号,没有短信宝账号？点击马上<a href="http://www.smsbao.com/" target="_blank"><font color="red"><b>注册</b></font></a>';
$_LANG['cfg_name']['smsbao_pass_word'] = '短信宝服务平台密码';
$_LANG['cfg_desc']['smsbao_pass_word'] = '请填写<a href="http://www.smsbao.com/" target="_blank"><font color="red"><b>短信宝服务平台</b></font></a>帐号的密码';
//$_LANG['cfg_name']['ecsdxt_account']='短信宝账户余额';
//$_LANG['cfg_desc']['ecsdxt_account']='短信宝账户余额';
$sql_uid = "SELECT value FROM " . $GLOBALS['ecs']->table('shop_config') . " WHERE code = 'smsbao_user_name'";
$row_uid = $db->getRow($sql_uid);
$sql_pwd = "SELECT value FROM " . $GLOBALS['ecs']->table('shop_config') . " WHERE code = 'smsbao_pass_word'";
$row_pwd = $db->getRow($sql_pwd);
$uid=$row_uid['value'];
$pwd=$row_pwd['value'];
$pwd=MD5($pwd);
//http://www.smsbao.com/query?u=USERNAME&p=PASSWORD
$get_url="http://www.smsbao.com/query?u=".$uid."&p=".$pwd;
$num_smsbao=file_get_contents($get_url);
$num_smsbao=str_replace("\n", "", $num_smsbao);
$num_smsbao_res=explode(",",$num_smsbao);
//判断短信条数
if($num_smsbao_res[1]>0&&$num_smsbao_res[1]<200){
	$num_smsbao_info="<span style='color:red;'>".$num_smsbao_res[1]."</span>条,您的账户余额已经所剩不多了，为了不影响您的正常使用，请及时<a href='http://www.smsbao.com/fee/' target='_blank' style='color:red;'>充值</a>";
}else if($num_smsbao_res[1]>=200){
	$num_smsbao_info=$num_smsbao_res[1];
}else if($num_smsbao_res[1]<=0){
	$num_smsbao_info="<span style='color:red;'>".$num_smsbao_res[1]."</span>条,已无剩余条数，请及时<a href='http://www.smsbao.com/fee/' target='_blank' style='color:red;'>充值</a>";
}
switch ($num_smsbao)
{
case 30:
  $smsbao_error_info="<strong>接口调用失败，账号密码错误</strong>  ";
  break;  
case 40:
  $smsbao_error_info="<strong>接口调用失败，账号不存在</strong>  ";
  break; 
case 41:
  $smsbao_error_info="<strong>接口调用失败，余额不足</strong>  ";
  break;
case 42:
  $smsbao_error_info="<strong>接口调用失败，账号过期</strong>  ";
  break;  
default:
  $smsbao_error_info="<strong>剩余条数</strong>：<strong>".$num_smsbao_info."</strong>&nbsp;&nbsp;";  
}
//$num_smsbao=explode(",",$$num_smsbao);
//$num_smsbao=$num_smsbao[1];
$_LANG['cfg_name']['smsbao_account_info']='短信宝账户余额';
$_LANG['cfg_desc']['smsbao_account_info']=$smsbao_error_info.'</br>没有短信宝账号？点击马上<a href="http://www.smsbao.com/" target="_blank"><font color="red"><b>注册</b></font></a>';
//$_LANG['cfg_name']['ecsdxt_shop_mobile'] = '商家手机号码';
//客户下订单时发送短信内容
//$_LANG['cfg_name']['smsbao_order_placed_value'] = '客户下订单时给商家发送短信内容';
//value  您有新的订单：{$order_sn}，收货人：{$consignee}，电话：{$tel}，请及时确认订单！
//客户付款时给商家发送短信提醒
//$_LANG['cfg_name']['smsbao_order_payed_value'] = '客户下付款时给商家发送短信内容';
//订单号 ：{$order_sn} 买家付款了。收货人：{$consignee}，电话：{$tel}。请及时安排发货！;
//商家配货时给客户发送短信
//$_LANG['cfg_name']['smsbao_order_picking_value'] = '客户下付款时给商家发送短信内容'；
//订单号：{$order_sn} 已于{$time}发货，如有问题请及时联系！
//短信宝配置信息结束
?>