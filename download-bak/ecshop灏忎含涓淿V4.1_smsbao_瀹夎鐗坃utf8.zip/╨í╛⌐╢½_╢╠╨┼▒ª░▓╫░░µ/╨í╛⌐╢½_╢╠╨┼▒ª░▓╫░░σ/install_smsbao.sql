DROP TABLE IF EXISTS `ecs_verifycode`;

CREATE TABLE `ecs_verifycode` (
`id` mediumint(8) unsigned NOT NULL auto_increment,
`mobile` char(12) NOT NULL,
`getip` char(15) NOT NULL,
`verifycode` char(6) NOT NULL,
`dateline` int(10) unsigned NOT NULL default '0',
`reguid` mediumint(8) unsigned default '0',
`regdateline` int(10) unsigned default '0',
`status` tinyint(1) NOT NULL default '1',
PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

INSERT INTO `ecs_shop_config` VALUES ('90', '0', 'smsbao', 'group', '', '', '', '1');

INSERT INTO `ecs_shop_config` VALUES ('9001', '90', 'smsbao_gateway', 'options', '1,2', '', '2', '1');

INSERT INTO `ecs_shop_config` VALUES ('9002', '90', 'smsbao_user_name', 'text', '', '', '', '1');
INSERT INTO `ecs_shop_config` VALUES ('9003', '90', 'smsbao_pass_word', 'password', '', '', '', '1');
INSERT INTO `ecs_shop_config` VALUES ('9005', '90', 'smsbao_account_info', '', '', '', '', '1');