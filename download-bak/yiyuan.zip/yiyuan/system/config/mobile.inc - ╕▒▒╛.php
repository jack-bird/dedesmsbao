<?php 
 return array (
  'cfg_mobile_2' => 
  array (
    'mid' => '',
    'mpass' => '',
    'mqianming' => '【2元云购】',
  ),
  'cfg_mobile_1' => 
  array (
    'mid' => '',
    'mpass' => '',
    'mqianming' => NULL,
  ),
  'cfg_mobile_on' => 3,
  'cfg_mobile_3' => 
  array (
    'mid' => 'cf_yyjg',
    'mpass' => 'EHWEnH',
    'mqianming' => '',
  ),
); 
?>