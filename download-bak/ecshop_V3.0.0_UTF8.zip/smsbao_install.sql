INSERT INTO `ecs_shop_config` VALUES ('90', '0', '短信宝设置', 'group', '', '', '', '1');
INSERT INTO `ecs_shop_config` VALUES ('', '90', '短信签名', 'text', '', '', '短信宝', '1');
INSERT INTO `ecs_shop_config` VALUES ('', '90', '短信宝账号', 'text', '', '', '注册地址：www.smsbao.com', '1');
INSERT INTO `ecs_shop_config` VALUES ('', '90', '短信宝密码', 'password', '', '', '', '1');